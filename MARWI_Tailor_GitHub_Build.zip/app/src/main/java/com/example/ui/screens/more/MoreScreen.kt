package com.example.ui.screens.more

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.TailorTopBar
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorNavy
import com.example.utils.BackupRestoreHelper
import kotlinx.coroutines.launch

@Composable
fun MoreScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()
    val overdueOrders by viewModel.overdueOrders.collectAsStateWithLifecycle()

    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonString by remember { mutableStateOf("") }

    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreInputString by remember { mutableStateOf("") }

    var showAboutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TailorTopBar(
                title = "بیشتر و تنظیمات",
                subtitle = "پشتیبان‌گیری، تنظیمات کارگاه و گزارش‌ها"
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // --- 1. Shop Info Card ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(TailorNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.ContentCut, contentDescription = null, tint = TailorGold, modifier = Modifier.size(28.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = settings.shopName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "مدیریت: ${settings.tailorName} • تلفن: ${settings.phone}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            if (settings.address.isNotBlank()) {
                                Text(
                                    text = settings.address,
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // --- 2. Menu Options ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column {
                        MoreMenuItem(
                            title = "تنظیمات کارگاه و خیاطی",
                            subtitle = "ویرایش نام خیاطی، نشانی، واحد پولی و متن قبض",
                            icon = Icons.Default.Settings,
                            onClick = { viewModel.navigateTo(ScreenDestination.ShopSettings) },
                            testTag = "menu_shop_settings"
                        )

                        MoreMenuItem(
                            title = "سفارش‌های معوق و دارای تأخیر",
                            subtitle = "${overdueOrders.size} سفارش تحویل‌نشده پس از موعد مقرر",
                            icon = Icons.Default.WarningAmber,
                            badgeText = if (overdueOrders.isNotEmpty()) "${overdueOrders.size} مورد" else null,
                            badgeColor = DebtRed,
                            onClick = { viewModel.navigateTo(ScreenDestination.OverdueOrders) },
                            testTag = "menu_overdue_orders"
                        )

                        MoreMenuItem(
                            title = "پشتیبان‌گیری از داده‌ها (خروجی JSON)",
                            subtitle = "دریافت نسخه پشتیبان کامل از تمامی مشتریان، سفارش‌ها و حسابداری",
                            icon = Icons.Default.Backup,
                            onClick = {
                                scope.launch {
                                    backupJsonString = BackupRestoreHelper.createBackupJson(viewModel.repository)
                                    showBackupDialog = true
                                }
                            },
                            testTag = "menu_backup"
                        )

                        MoreMenuItem(
                            title = "بازیابی اطلاعات (Restore)",
                            subtitle = "وارد کردن اطلاعات از فایل یا کد پشتیبان قبلی",
                            icon = Icons.Default.Restore,
                            onClick = {
                                restoreInputString = ""
                                showRestoreDialog = true
                            },
                            testTag = "menu_restore"
                        )

                        MoreMenuItem(
                            title = "درباره MARWI Tailor Pro",
                            subtitle = "نسخه ۱.۰.۰ • سامانه آفلاین مدیریت خیاطی مردانه",
                            icon = Icons.Default.Info,
                            onClick = { showAboutDialog = true },
                            testTag = "menu_about"
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    // Backup Dialog
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = {
                Text(
                    text = "نسخه پشتیبان پایگاه داده",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "کد زیر حاوی تمام اطلاعات مشتریان، سفارش‌ها، اندازه‌ها و حسابداری شما است. می‌توانید آن را کپی کرده و در محل امنی ذخیره نمایید:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = backupJsonString,
                        onValueChange = {},
                        readOnly = true,
                        minLines = 6,
                        maxLines = 8,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("MARWI Backup JSON", backupJsonString)
                        clipboard.setPrimaryClip(clip)
                        showBackupDialog = false
                        scope.launch {
                            snackbarHostState.showSnackbar("متن پشتیبان در حافظه کپی شد.")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("کپی در کلیپ‌بورد", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBackupDialog = false }, shape = RoundedCornerShape(8.dp)) {
                    Text("بستن")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = {
                Text(
                    text = "بازیابی اطلاعات از نسخه پشتیبان",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "متن JSON پشتیبان قبلی را در کادر زیر وارد کنید:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = restoreInputString,
                        onValueChange = { restoreInputString = it },
                        placeholder = { Text("متن پشتیبان JSON را اینجا الصاق نمایید...") },
                        minLines = 5,
                        maxLines = 7,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreInputString.isNotBlank()) {
                            scope.launch {
                                val result = BackupRestoreHelper.restoreFromJson(restoreInputString, viewModel.repository)
                                showRestoreDialog = false
                                if (result.isSuccess) {
                                    snackbarHostState.showSnackbar(result.getOrNull() ?: "بازیابی با موفقیت انجام شد")
                                } else {
                                    snackbarHostState.showSnackbar("خطا در ساختار فایل پشتیبان!")
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("بازیابی اطلاعات", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreDialog = false }, shape = RoundedCornerShape(8.dp)) {
                    Text("انصراف")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Text(
                    text = "درباره MARWI Tailor Pro",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "اپلیکیشن حرفه‌ای مدیریت خیاطی مردانه MARWI Tailor Pro",
                        fontWeight = FontWeight.Bold,
                        color = TailorGold
                    )
                    Text(
                        text = "طراحی شده با Kotlin و Jetpack Compose بر اساس استاندارد Material 3 و پشتیبانی کامل از تقویم شمسی، پایگاه داده محلی Room بدون نیاز به اینترنت، مدیریت چندمرحله‌ای سفارش‌ها و محاسبات دقیق حسابداری خیاطی.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "نسخه: 1.0.0 Pro\nتوسعه‌یافته برای خیاطان لوکس و سفارشی‌دوز",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = TailorNavy), shape = RoundedCornerShape(8.dp)) {
                    Text("متوجه شدم")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
fun MoreMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badgeText: String? = null,
    badgeColor: Color = DebtRed,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(TailorNavy.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = TailorNavy, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            )
        }

        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(badgeColor)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(text = badgeText, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
    }
}
