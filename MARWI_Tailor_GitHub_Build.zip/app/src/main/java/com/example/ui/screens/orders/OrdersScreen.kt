package com.example.ui.screens.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OrderStatus
import com.example.data.local.OrderWithCustomerInfo
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.utils.CurrencyFormatter
import com.example.utils.PersianDateHelper

data class OrderFilterOption(
    val status: String,
    val title: String
)

val orderFilters = listOf(
    OrderFilterOption("ALL", "همه"),
    OrderFilterOption(OrderStatus.PENDING, "در انتظار دوخت"),
    OrderFilterOption(OrderStatus.IN_PROGRESS, "در حال دوخت"),
    OrderFilterOption(OrderStatus.READY, "آماده تحویل"),
    OrderFilterOption(OrderStatus.DELIVERED, "تحویل شده"),
    OrderFilterOption(OrderStatus.CANCELLED, "لغو شده")
)

@Composable
fun OrdersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.allOrdersWithCustomer.collectAsStateWithLifecycle()
    val searchQuery by viewModel.orderSearchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.orderStatusFilter.collectAsStateWithLifecycle()
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()

    val currency = settings.currencyUnit

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(ScreenDestination.AddEditOrder()) },
                containerColor = TailorNavy,
                contentColor = TailorGold,
                shape = CircleShape,
                modifier = Modifier.testTag("fab_add_order")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "ثبت سفارش جدید")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.orderSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("search_order_field"),
                placeholder = { Text("جستجوی سفارش، مشتری، شماره تماس یا مدل...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TailorNavy)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.orderSearchQuery.value = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "پاک کردن")
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TailorGoldDark,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                singleLine = true
            )

            // Status Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                orderFilters.forEach { option ->
                    val isSelected = selectedFilter == option.status
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.orderStatusFilter.value = option.status },
                        label = {
                            Text(
                                text = option.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TailorNavy,
                            selectedLabelColor = Color.White,
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("filter_chip_${option.status}")
                    )
                }
            }

            // Results count
            Text(
                text = "تعداد سفارش‌ها: ${orders.size} مورد",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
            )

            if (orders.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.ContentCut,
                    title = "سفارشی با این شرایط یافت نشد",
                    description = if (searchQuery.isNotBlank() || selectedFilter != "ALL") "فیلترها را تغییر دهید یا سفارش جدید ثبت کنید." else "اولین سفارش خیاطی را با دکمه زیر ایجاد کنید.",
                    actionButtonText = "ثبت سفارش جدید",
                    onActionClick = { viewModel.navigateTo(ScreenDestination.AddEditOrder()) }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(orders, key = { it.id }) { order ->
                        OrderItemCard(
                            order = order,
                            currency = currency,
                            onClick = {
                                viewModel.navigateTo(ScreenDestination.OrderDetail(order.id))
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OrderItemCard(
    order: OrderWithCustomerInfo,
    currency: String,
    onClick: () -> Unit
) {
    val isOverdue = PersianDateHelper.isOverdue(order.deliveryDateShamsi) &&
            order.status != OrderStatus.DELIVERED &&
            order.status != OrderStatus.CANCELLED

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("order_card_${order.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top row: Customer Name + Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = order.customerName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${order.orderNumber})",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
                StatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Middle row: Clothing type and description
            Text(
                text = order.orderType,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TailorNavy
                )
            )
            if (order.description.isNotBlank()) {
                Text(
                    text = order.description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dates and financial row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Delivery date with alert if overdue
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isOverdue) Icons.Default.WarningAmber else Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = if (isOverdue) DebtRed else TailorNavy,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "تحویل: ${order.deliveryDateShamsi}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isOverdue) DebtRed else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                    if (isOverdue) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(DebtRed.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = "تأخیر", color = DebtRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Balance
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "کل: ${CurrencyFormatter.format(order.totalAmount, currency)}",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    if (order.remainingAmount > 0) {
                        Text(
                            text = "باقیمانده: ${CurrencyFormatter.format(order.remainingAmount, currency)}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = DebtRed,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    } else {
                        Text(
                            text = "تسویه شده",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = PaidGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }
    }
}
