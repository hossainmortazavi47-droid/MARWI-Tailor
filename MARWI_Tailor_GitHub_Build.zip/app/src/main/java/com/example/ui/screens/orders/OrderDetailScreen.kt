package com.example.ui.screens.orders

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OrderStatus
import com.example.data.local.PaymentEntity
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TailorConfirmDialog
import com.example.ui.components.TailorTopBar
import com.example.ui.screens.customers.CustomerPaymentRow
import com.example.ui.screens.customers.MeasurementCard
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.utils.CurrencyFormatter
import com.example.utils.InvoiceGenerator
import com.example.utils.PersianDateHelper
import kotlinx.coroutines.launch

val orderStatusesList = listOf(
    OrderStatus.PENDING to "در انتظار دوخت",
    OrderStatus.IN_PROGRESS to "در حال دوخت",
    OrderStatus.READY to "آماده تحویل",
    OrderStatus.DELIVERED to "تحویل داده شد",
    OrderStatus.CANCELLED to "لغو شده"
)

@Composable
fun OrderDetailScreen(
    orderId: Long,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val order by viewModel.repository.getOrderById(orderId).collectAsStateWithLifecycle(initialValue = null)
    val orderItems by viewModel.repository.getOrderItems(orderId).collectAsStateWithLifecycle(initialValue = emptyList())
    val payments by viewModel.repository.getPaymentsForOrder(orderId).collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()

    val customer by viewModel.repository.getCustomerById(order?.customerId ?: 0L).collectAsStateWithLifecycle(initialValue = null)
    val measurement by viewModel.repository.getMeasurementById(order?.measurementId ?: 0L).collectAsStateWithLifecycle(initialValue = null)

    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val currency = settings.currencyUnit

    Scaffold(
        topBar = {
            TailorTopBar(
                title = "جزئیات سفارش ${order?.orderNumber ?: ""}",
                subtitle = customer?.fullName,
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    IconButton(
                        onClick = {
                            if (order != null && customer != null) {
                                val invoice = InvoiceGenerator.generateTextInvoice(
                                    settings = settings,
                                    customer = customer!!,
                                    order = order!!,
                                    items = orderItems
                                )
                                InvoiceGenerator.shareInvoice(context, invoice, order!!.orderNumber)
                            }
                        },
                        modifier = Modifier.testTag("btn_share_invoice")
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "اشتراک رسید", tint = TailorNavy)
                    }

                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.testTag("btn_delete_order")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف سفارش", tint = DebtRed)
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (order != null && order!!.remainingAmount > 0) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "مانده بدهی: ${CurrencyFormatter.format(order!!.remainingAmount, currency)}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DebtRed
                                )
                            )
                            Text(
                                text = "کل سفارش: ${CurrencyFormatter.format(order!!.totalAmount, currency)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }

                        Button(
                            onClick = { showAddPaymentDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_record_payment_footer")
                        ) {
                            Icon(imageVector = Icons.Default.Payment, contentDescription = null, tint = TailorGold)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ثبت پرداخت جدید", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (order == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("اطلاعات سفارش یافت نشد.")
            }
            return@Scaffold
        }

        val ord = order!!

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // --- 1. Order Status Stepper ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "تغییر وضعیت سفارش:",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TailorNavy
                                )
                            )
                            StatusBadge(status = ord.status)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            orderStatusesList.forEach { (statusKey, statusTitle) ->
                                val isSelected = ord.status == statusKey
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.updateOrderStatus(ord.id, statusKey)
                                        scope.launch {
                                            snackbarHostState.showSnackbar("وضعیت سفارش به «$statusTitle» تغییر یافت.")
                                        }
                                    },
                                    label = {
                                        Text(
                                            text = statusTitle,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 11.sp
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = TailorNavy,
                                        selectedLabelColor = Color.White,
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    shape = RoundedCornerShape(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // --- 2. Customer Summary Card ---
            if (customer != null) {
                item {
                    val cust = customer!!
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.navigateTo(ScreenDestination.CustomerDetail(cust.id))
                            },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(14.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(TailorNavy),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = TailorGold)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = cust.fullName,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = cust.phone,
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                                        data = Uri.parse("tel:${cust.phone}")
                                    }
                                    context.startActivity(dialIntent)
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(PaidGreen.copy(alpha = 0.12f))
                            ) {
                                Icon(imageVector = Icons.Default.Call, contentDescription = "تماس با مشتری", tint = PaidGreen)
                            }
                        }
                    }
                }
            }

            // --- 3. Order Information & Dates ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "مشخصات لباس و موعد تحویل",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TailorNavy
                            )
                        )

                        Text(
                            text = "نوع کلی: ${ord.orderType}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )

                        if (ord.description.isNotBlank()) {
                            Text(
                                text = "توضیحات: ${ord.description}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("تاریخ ثبت سفارش:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(ord.registrationDateShamsi, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("موعد تحویل:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(ord.deliveryDateShamsi, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TailorNavy)
                            }
                        }

                        if (ord.specialNotes.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(TailorGold.copy(alpha = 0.1f))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "یادداشت اختصاصی: ${ord.specialNotes}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TailorNavy)
                                )
                            }
                        }
                    }
                }
            }

            // --- 4. Order Items Breakdown ---
            item {
                SectionHeader(title = "اقلام سفارش (${orderItems.size} قلم)")
            }

            items(orderItems) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${item.clothingType} × ${item.quantity}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            if (item.notes.isNotBlank()) {
                                Text(
                                    text = item.notes,
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        if (item.unitPrice > 0) {
                            Text(
                                text = CurrencyFormatter.format(item.unitPrice * item.quantity, currency),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            // --- 5. Linked Measurement Preview ---
            if (measurement != null) {
                item {
                    SectionHeader(title = "اندازه‌گیری متصل به سفارش")
                    MeasurementCard(
                        measurement = measurement!!,
                        onEdit = {
                            customer?.let {
                                viewModel.navigateTo(ScreenDestination.CustomerDetail(it.id))
                            }
                        },
                        onDelete = {}
                    )
                }
            }

            // --- 6. Payment History ---
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SectionHeader(title = "سابقه پرداخت‌ها (${payments.size})")

                    OutlinedButton(
                        onClick = { showAddPaymentDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_add_payment")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ثبت دریافتی", fontSize = 12.sp)
                    }
                }
            }

            if (payments.isEmpty()) {
                item {
                    Text(
                        text = "هنوز پرداختی برای این سفارش ثبت نشده است.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            } else {
                items(payments, key = { it.id }) { payment ->
                    CustomerPaymentRow(payment = payment, currency = currency)
                }
            }

            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }

    // Add Payment Dialog
    if (showAddPaymentDialog && order != null) {
        AddPaymentDialog(
            orderRemainingDebt = order!!.remainingAmount,
            currency = currency,
            onDismiss = { showAddPaymentDialog = false },
            onSave = { amount, method, notes, date ->
                viewModel.addPayment(
                    orderId = order!!.id,
                    customerId = order!!.customerId,
                    amount = amount,
                    paymentMethod = method,
                    notes = notes,
                    paymentDate = date,
                    onDone = {
                        showAddPaymentDialog = false
                        scope.launch {
                            snackbarHostState.showSnackbar("پرداخت ${CurrencyFormatter.format(amount, currency)} با موفقیت ثبت شد.")
                        }
                    }
                )
            }
        )
    }

    // Delete Order Confirm Dialog
    TailorConfirmDialog(
        show = showDeleteConfirmDialog,
        title = "حذف سفارش",
        message = "آیا از حذف سفارش شماره «${order?.orderNumber}» اطمینان دارید؟",
        confirmButtonText = "حذف سفارش",
        isDestructive = true,
        onConfirm = {
            order?.let {
                viewModel.deleteOrder(it) {
                    showDeleteConfirmDialog = false
                    viewModel.navigateBack()
                }
            }
        },
        onDismiss = { showDeleteConfirmDialog = false }
    )
}

@Composable
fun AddPaymentDialog(
    orderRemainingDebt: Long,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (amount: Long, method: String, notes: String, date: String) -> Unit
) {
    var amountText by remember { mutableStateOf(if (orderRemainingDebt > 0) orderRemainingDebt.toString() else "1000") }
    var selectedMethod by remember { mutableStateOf("نقدی") }
    var notes by remember { mutableStateOf("") }
    var paymentDate by remember { mutableStateOf(PersianDateHelper.todayFormatted()) }

    var warningDebtOverpay by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "ثبت دریافتی / پرداخت وجه",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TailorNavy
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "مانده بدهی این سفارش: ${CurrencyFormatter.format(orderRemainingDebt, currency)}",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = DebtRed,
                        fontWeight = FontWeight.Bold
                    )
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        val parsed = it.toLongOrNull() ?: 0L
                        warningDebtOverpay = parsed > orderRemainingDebt && orderRemainingDebt > 0
                    },
                    label = { Text("مبلغ پرداختی ($currency) *") },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("payment_amount_input")
                )

                if (warningDebtOverpay) {
                    Text(
                        text = "هشدار: مبلغ وارد شده از مانده بدهی سفارش بیشتر است!",
                        style = MaterialTheme.typography.labelSmall.copy(color = DebtRed, fontWeight = FontWeight.Bold)
                    )
                }

                OutlinedTextField(
                    value = paymentDate,
                    onValueChange = { paymentDate = it },
                    label = { Text("تاریخ پرداخت (شمسی)") },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "روش پرداخت:",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("نقدی", "کارت‌خوان", "حواله", "سایر").forEach { method ->
                        val isSelected = selectedMethod == method
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TailorNavy else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedMethod = method }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = method,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("توضیحات و شماره پیگیری (اختیاری)") },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toLongOrNull() ?: 0L
                    if (amount > 0) {
                        onSave(amount, selectedMethod, notes.trim(), paymentDate.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("btn_save_payment_confirm")
            ) {
                Text("تأیید و ثبت", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("انصراف")
            }
        },
        shape = RoundedCornerShape(16.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}
