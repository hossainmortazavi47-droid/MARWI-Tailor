package com.example.ui.screens.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ExpenseEntity
import com.example.data.local.PaymentEntity
import com.example.ui.MainViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.TailorConfirmDialog
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorNavy
import com.example.ui.theme.TailorNavyDark
import com.example.utils.CurrencyFormatter
import com.example.utils.PersianDateHelper

import androidx.compose.foundation.clickable
import androidx.compose.material3.ExperimentalMaterial3Api

val expenseCategories = listOf("پارچه و آستر", "ملحقات و دکمه", "کرایه کارگاه", "برق و خدمات", "دستمزد شاگردان", "تعمیر چرخ و ابزار", "سایر")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val payments by viewModel.allPayments.collectAsStateWithLifecycle()
    val expenses by viewModel.allExpenses.collectAsStateWithLifecycle()
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()
    val todayIncome by viewModel.todayIncome.collectAsStateWithLifecycle()
    val totalDebt by viewModel.totalDebt.collectAsStateWithLifecycle()

    val currency = settings.currencyUnit

    val totalRevenue = payments.sumOf { it.amount }
    val totalExpenses = expenses.sumOf { it.amount }
    val netProfit = totalRevenue - totalExpenses

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expenseToDelete by remember { mutableStateOf<ExpenseEntity?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            if (selectedTabIndex == 1) {
                FloatingActionButton(
                    onClick = { showAddExpenseDialog = true },
                    containerColor = TailorNavy,
                    contentColor = TailorGold,
                    shape = CircleShape,
                    modifier = Modifier.testTag("fab_add_expense")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "ثبت هزینه کارگاه")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // --- 1. Workshop Financial Performance Overview ---
                item {
                    FinancialOverviewCard(
                        totalRevenue = totalRevenue,
                        totalExpenses = totalExpenses,
                        netProfit = netProfit,
                        todayIncome = todayIncome ?: 0L,
                        totalDebt = totalDebt ?: 0L,
                        currency = currency
                    )
                }

                // --- 2. Tabs: Payments vs Workshop Expenses ---
                item {
                    PrimaryTabRow(
                        selectedTabIndex = selectedTabIndex,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = TailorNavy,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                    ) {
                        Tab(
                            selected = selectedTabIndex == 0,
                            onClick = { selectedTabIndex = 0 },
                            text = { Text("دریافتی‌های خیاطی (${payments.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                        Tab(
                            selected = selectedTabIndex == 1,
                            onClick = { selectedTabIndex = 1 },
                            text = { Text("هزینه‌های کارگاه (${expenses.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                    }
                }

                // --- 3. Tab Contents ---
                if (selectedTabIndex == 0) {
                    if (payments.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Default.Payments,
                                title = "هنوز دریافتی ثبت نشده است",
                                description = "دریافتی‌ها هنگام ثبت سفارش یا در صفحه سفارش‌ها افزوده می‌شوند."
                            )
                        }
                    } else {
                        items(payments, key = { it.id }) { payment ->
                            FinancePaymentItem(payment = payment, currency = currency)
                        }
                    }
                } else {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "فهرست هزینه‌های جاری کارگاه",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TailorNavy
                                )
                            )

                            Button(
                                onClick = { showAddExpenseDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = TailorGold, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ثبت هزینه", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (expenses.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Default.Receipt,
                                title = "هنوز هزینه‌ای برای کارگاه ثبت نشده است",
                                description = "هزینه‌های پارچه، آستر، دکمه، برق، کرایه و دستمزد شاگردان را اینجا ثبت کنید تا سود دقیق کارگاه محاسبه شود.",
                                actionButtonText = "ثبت اولین هزینه کارگاه",
                                onActionClick = { showAddExpenseDialog = true }
                            )
                        }
                    } else {
                        items(expenses, key = { it.id }) { expense ->
                            FinanceExpenseItem(
                                expense = expense,
                                currency = currency,
                                onDelete = { expenseToDelete = expense }
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Add Expense Dialog
    if (showAddExpenseDialog) {
        AddExpenseDialog(
            currency = currency,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { expense ->
                viewModel.addExpense(expense) {
                    showAddExpenseDialog = false
                }
            }
        )
    }

    // Delete Expense Confirm Dialog
    TailorConfirmDialog(
        show = expenseToDelete != null,
        title = "حذف هزینه",
        message = "آیا از حذف هزینه «${expenseToDelete?.title}» اطمینان دارید؟",
        confirmButtonText = "حذف هزینه",
        isDestructive = true,
        onConfirm = {
            expenseToDelete?.let {
                viewModel.deleteExpense(it)
                expenseToDelete = null
            }
        },
        onDismiss = { expenseToDelete = null }
    )
}

@Composable
fun FinancialOverviewCard(
    totalRevenue: Long,
    totalExpenses: Long,
    netProfit: Long,
    todayIncome: Long,
    totalDebt: Long,
    currency: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = TailorNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "سود خالص تخمینی کارگاه",
                        style = MaterialTheme.typography.bodySmall.copy(color = TailorGold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CurrencyFormatter.format(netProfit, currency),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(TailorGold.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (netProfit >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                        contentDescription = null,
                        tint = TailorGold,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sub stats row: Income vs Expenses
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.1f))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(PaidGreen))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("کل دریافتی خیاطی", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = CurrencyFormatter.format(totalRevenue, currency),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(DebtRed))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("کل هزینه‌های کارگاه", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = CurrencyFormatter.format(totalExpenses, currency),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Today's income & Debt
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "دریافتی امروز: ${CurrencyFormatter.format(todayIncome, currency)}",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
                Text(
                    text = "مجموع طلب از مشتریان: ${CurrencyFormatter.format(totalDebt, currency)}",
                    fontSize = 11.sp,
                    color = TailorGold
                )
            }
        }
    }
}

@Composable
fun FinancePaymentItem(
    payment: PaymentEntity,
    currency: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "پرداخت سفارش شماره ${payment.orderId}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "روش: ${payment.paymentMethod} • تاریخ ${payment.paymentDateShamsi}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                if (payment.notes.isNotBlank()) {
                    Text(
                        text = payment.notes,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Text(
                text = "+ ${CurrencyFormatter.format(payment.amount, currency)}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = PaidGreen
                )
            )
        }
    }
}

@Composable
fun FinanceExpenseItem(
    expense: ExpenseEntity,
    currency: String,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(TailorNavy.copy(alpha = 0.08f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = expense.category,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TailorNavy
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = expense.title,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "تاریخ: ${expense.expenseDateShamsi}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                if (expense.notes.isNotBlank()) {
                    Text(
                        text = expense.notes,
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "- ${CurrencyFormatter.format(expense.amount, currency)}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DebtRed
                    )
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف هزینه", tint = DebtRed, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun AddExpenseDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (ExpenseEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("پارچه و آستر") }
    var dateShamsi by remember { mutableStateOf(PersianDateHelper.todayFormatted()) }
    var notes by remember { mutableStateOf("") }

    var titleError by remember { mutableStateOf(false) }
    var amountError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "ثبت هزینه کارگاه خیاطی",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TailorNavy
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        titleError = it.isBlank()
                    },
                    label = { Text("عنوان هزینه *") },
                    placeholder = { Text("مثال: خرید آستر، دکمه، سوزن، کرایه...") },
                    singleLine = true,
                    isError = titleError,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        amountError = it.toLongOrNull() == null || it.toLong() <= 0
                    },
                    label = { Text("مبلغ هزینه ($currency) *") },
                    singleLine = true,
                    isError = amountError,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("expense_amount_input")
                )

                OutlinedTextField(
                    value = dateShamsi,
                    onValueChange = { dateShamsi = it },
                    label = { Text("تاریخ هزینه (شمسی)") },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("دسته‌بندی هزینه:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                // Category selection chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    expenseCategories.take(4).forEach { cat ->
                        val isSelected = selectedCategory == cat
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) TailorNavy else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedCategory = cat }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cat, fontSize = 10.sp, color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("توضیحات و فروشنده (اختیاری)") },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toLongOrNull() ?: 0L
                    if (title.isBlank()) {
                        titleError = true
                        return@Button
                    }
                    if (amount <= 0) {
                        amountError = true
                        return@Button
                    }
                    val expense = ExpenseEntity(
                        title = title.trim(),
                        amount = amount,
                        category = selectedCategory,
                        expenseDateShamsi = dateShamsi.trim(),
                        notes = notes.trim()
                    )
                    onSave(expense)
                },
                colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("ثبت هزینه", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("انصراف")
            }
        },
        shape = RoundedCornerShape(16.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}
