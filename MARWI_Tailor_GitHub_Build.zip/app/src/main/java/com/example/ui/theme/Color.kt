package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MARWI Tailor Pro Luxury Palette
val TailorNavy = Color(0xFF172B46)
val TailorNavyDark = Color(0xFF0F1D30)
val TailorNavyLight = Color(0xFF243F63)
val TailorNavySurface = Color(0xFF1C3454)

val TailorGold = Color(0xFFD5B779)
val TailorGoldDark = Color(0xFFB59350)
val TailorGoldLight = Color(0xFFE8D4A8)
val TailorGoldContainer = Color(0xFFFBF6EB)

val TailorIvory = Color(0xFFF6F4EE)
val TailorSurfaceLight = Color(0xFFFFFFFF)
val TailorCardBorderLight = Color(0xFFE6E2D8)

val TailorTextPrimaryLight = Color(0xFF111D2D)
val TailorTextSecondaryLight = Color(0xFF5D6B7F)

// Dark mode colors
val TailorDarkBackground = Color(0xFF0B1420)
val TailorDarkSurface = Color(0xFF132236)
val TailorDarkCard = Color(0xFF1A2F4A)
val TailorDarkCardBorder = Color(0xFF284366)
val TailorTextPrimaryDark = Color(0xFFF6F4EE)
val TailorTextSecondaryDark = Color(0xFFA6B7CC)

// Functional Status Colors
val StatusPending = Color(0xFF2563EB)
val StatusInProgress = Color(0xFFD97706)
val StatusReady = Color(0xFF059669)
val StatusDelivered = Color(0xFF16A34A)
val StatusCancelled = Color(0xFF64748B)

val DebtRed = Color(0xFFDC2626)
val DebtRedContainer = Color(0xFFFEE2E2)
val PaidGreen = Color(0xFF16A34A)
val PaidGreenContainer = Color(0xFFDCFCE7)
