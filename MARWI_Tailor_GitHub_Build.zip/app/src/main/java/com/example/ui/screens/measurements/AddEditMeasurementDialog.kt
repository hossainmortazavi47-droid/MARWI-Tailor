package com.example.ui.screens.measurements

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MeasurementEntity
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.utils.PersianDateHelper

@Composable
fun AddEditMeasurementDialog(
    customerId: Long,
    existingMeasurement: MeasurementEntity?,
    onDismiss: () -> Unit,
    onSave: (MeasurementEntity) -> Unit
) {
    var title by remember { mutableStateOf(existingMeasurement?.title ?: "اندازه جدید") }
    var dateShamsi by remember { mutableStateOf(existingMeasurement?.dateShamsi?.ifEmpty { PersianDateHelper.todayFormatted() } ?: PersianDateHelper.todayFormatted()) }

    // Upper body (قد، سینه، کمر، شکم، باسن، شانه، آستین، بازو، مچ، یقه)
    var shirtLength by remember { mutableStateOf(existingMeasurement?.shirtLength ?: "") }
    var chest by remember { mutableStateOf(existingMeasurement?.chest ?: "") }
    var waist by remember { mutableStateOf(existingMeasurement?.waist ?: "") }
    var stomach by remember { mutableStateOf(existingMeasurement?.stomach ?: "") }
    var hips by remember { mutableStateOf(existingMeasurement?.hips ?: "") }
    var shoulder by remember { mutableStateOf(existingMeasurement?.shoulder ?: "") }
    var sleeveLength by remember { mutableStateOf(existingMeasurement?.sleeveLength ?: "") }
    var armBicep by remember { mutableStateOf(existingMeasurement?.armBicep ?: "") }
    var wrist by remember { mutableStateOf(existingMeasurement?.wrist ?: "") }
    var collar by remember { mutableStateOf(existingMeasurement?.collar ?: "") }

    // Lower body (قد پتلون، کمر، ران، زانو، دمپا، فاق)
    var pantsLength by remember { mutableStateOf(existingMeasurement?.pantsLength ?: "") }
    var pantsWaist by remember { mutableStateOf(existingMeasurement?.pantsWaist ?: "") }
    var thigh by remember { mutableStateOf(existingMeasurement?.thigh ?: "") }
    var knee by remember { mutableStateOf(existingMeasurement?.knee ?: "") }
    var pantsCuff by remember { mutableStateOf(existingMeasurement?.pantsCuff ?: "") }
    var crotch by remember { mutableStateOf(existingMeasurement?.crotch ?: "") }

    var customNotes by remember { mutableStateOf(existingMeasurement?.customNotes ?: "") }

    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existingMeasurement == null) "ثبت اندازه جدید مشتری" else "ویرایش اندازه (${title})",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TailorNavy
                )
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Title and Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("عنوان اندازه (کت، پیراهن،...)") },
                        modifier = Modifier.weight(1.5f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    OutlinedTextField(
                        value = dateShamsi,
                        onValueChange = { dateShamsi = it },
                        label = { Text("تاریخ (شمسی)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // --- Upper Body Section ---
                MeasurementSectionLabel("اندازه‌های پیراهن / کت (بالاتنه)")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MeasureInput(label = "قد لباس", value = shirtLength, onValueChange = { shirtLength = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور سینه", value = chest, onValueChange = { chest = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور کمر", value = waist, onValueChange = { waist = it }, modifier = Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MeasureInput(label = "دور شکم", value = stomach, onValueChange = { stomach = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور باسن", value = hips, onValueChange = { hips = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "عرض شانه", value = shoulder, onValueChange = { shoulder = it }, modifier = Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MeasureInput(label = "طول آستین", value = sleeveLength, onValueChange = { sleeveLength = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور بازو", value = armBicep, onValueChange = { armBicep = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور مچ", value = wrist, onValueChange = { wrist = it }, modifier = Modifier.weight(1f))
                }

                MeasureInput(label = "دور گردن / یقه", value = collar, onValueChange = { collar = it }, modifier = Modifier.fillMaxWidth(0.5f))

                Spacer(modifier = Modifier.height(4.dp))

                // --- Lower Body Section ---
                MeasurementSectionLabel("اندازه‌های پتلون / تنبان (پایین‌تنه)")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MeasureInput(label = "قد پتلون", value = pantsLength, onValueChange = { pantsLength = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور کمر شلوار", value = pantsWaist, onValueChange = { pantsWaist = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دور ران", value = thigh, onValueChange = { thigh = it }, modifier = Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MeasureInput(label = "دور زانو", value = knee, onValueChange = { knee = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "دمپای پتلون", value = pantsCuff, onValueChange = { pantsCuff = it }, modifier = Modifier.weight(1f))
                    MeasureInput(label = "فاق شلوار", value = crotch, onValueChange = { crotch = it }, modifier = Modifier.weight(1f))
                }

                OutlinedTextField(
                    value = customNotes,
                    onValueChange = { customNotes = it },
                    label = { Text("سایر اندازه‌ها و یادداشت برش") },
                    shape = RoundedCornerShape(8.dp),
                    minLines = 2,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalEntity = existingMeasurement?.copy(
                        title = title.trim().ifEmpty { "اندازه عمومی" },
                        dateShamsi = dateShamsi.trim(),
                        shirtLength = shirtLength.trim(),
                        chest = chest.trim(),
                        waist = waist.trim(),
                        stomach = stomach.trim(),
                        hips = hips.trim(),
                        shoulder = shoulder.trim(),
                        sleeveLength = sleeveLength.trim(),
                        armBicep = armBicep.trim(),
                        wrist = wrist.trim(),
                        collar = collar.trim(),
                        pantsLength = pantsLength.trim(),
                        pantsWaist = pantsWaist.trim(),
                        thigh = thigh.trim(),
                        knee = knee.trim(),
                        pantsCuff = pantsCuff.trim(),
                        crotch = crotch.trim(),
                        customNotes = customNotes.trim(),
                        updatedAt = System.currentTimeMillis()
                    ) ?: MeasurementEntity(
                        customerId = customerId,
                        title = title.trim().ifEmpty { "اندازه عمومی" },
                        dateShamsi = dateShamsi.trim(),
                        shirtLength = shirtLength.trim(),
                        chest = chest.trim(),
                        waist = waist.trim(),
                        stomach = stomach.trim(),
                        hips = hips.trim(),
                        shoulder = shoulder.trim(),
                        sleeveLength = sleeveLength.trim(),
                        armBicep = armBicep.trim(),
                        wrist = wrist.trim(),
                        collar = collar.trim(),
                        pantsLength = pantsLength.trim(),
                        pantsWaist = pantsWaist.trim(),
                        thigh = thigh.trim(),
                        knee = knee.trim(),
                        pantsCuff = pantsCuff.trim(),
                        crotch = crotch.trim(),
                        customNotes = customNotes.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                    onSave(finalEntity)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TailorNavy,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("dialog_save_measurement_btn")
            ) {
                Text("ذخیره اندازه", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("انصراف")
            }
        },
        shape = RoundedCornerShape(16.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}

@Composable
private fun MeasurementSectionLabel(title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(14.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(TailorGoldDark)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TailorNavy
            )
        )
    }
}

@Composable
private fun MeasureInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    )
}
