package com.example.ui.screens.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CustomerEntity
import com.example.data.local.MeasurementEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.TailorTopBar
import com.example.ui.screens.customers.AddEditCustomerDialog
import com.example.ui.screens.measurements.AddEditMeasurementDialog
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.utils.CurrencyFormatter
import com.example.utils.PersianDateHelper
import kotlinx.coroutines.launch
import kotlin.math.max

data class TempOrderItem(
    var clothingType: String,
    var quantity: Int,
    var unitPrice: Long,
    var notes: String
)

val clothingTypePresets = listOf("دریشی", "پیراهن", "پتلون", "واسکت", "تنبان", "کت تک", "پالتو", "سایر")
val paymentMethods = listOf("نقدی", "کارت‌خوان", "حواله بانکی", "سایر")

@Composable
fun AddEditOrderScreen(
    preSelectedCustomerId: Long?,
    orderIdToEdit: Long?,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val customers by viewModel.allCustomers.collectAsStateWithLifecycle()
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()
    val currency = settings.currencyUnit

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var showQuickAddCustomer by remember { mutableStateOf(false) }

    var orderNumber by remember { mutableStateOf("ORD-${(100 + (1..899).random())}") }
    var orderType by remember { mutableStateOf("دریشی") }
    var description by remember { mutableStateOf("") }
    var registrationDate by remember { mutableStateOf(PersianDateHelper.todayFormatted()) }
    var deliveryDate by remember { mutableStateOf(PersianDateHelper.addDaysToToday(5)) }
    var specialNotes by remember { mutableStateOf("") }

    val orderItems = remember {
        mutableStateListOf(
            TempOrderItem("دریشی", 1, 6000L, "دوخت سفارشی")
        )
    }

    var manualTotalOverride by remember { mutableStateOf<Long?>(null) }
    val calculatedTotal = orderItems.sumOf { it.quantity * it.unitPrice }
    val totalAmount = manualTotalOverride ?: calculatedTotal

    var advancePaymentText by remember { mutableStateOf("2000") }
    val advancePayment = advancePaymentText.toLongOrNull() ?: 0L
    val remainingAmount = max(0L, totalAmount - advancePayment)

    var selectedPaymentMethod by remember { mutableStateOf("نقدی") }

    // Measurement selector
    var availableMeasurements by remember { mutableStateOf<List<MeasurementEntity>>(emptyList()) }
    var selectedMeasurementId by remember { mutableStateOf<Long?>(null) }
    var showAddMeasurementDialog by remember { mutableStateOf(false) }

    // Initialize customer if passed
    LaunchedEffect(preSelectedCustomerId, customers) {
        if (preSelectedCustomerId != null && selectedCustomer == null) {
            val found = customers.find { it.id == preSelectedCustomerId }
            if (found != null) {
                selectedCustomer = found
            }
        }
    }

    // Load customer's measurements when customer changes
    LaunchedEffect(selectedCustomer) {
        selectedCustomer?.let { cust ->
            viewModel.repository.getMeasurementsForCustomer(cust.id).collect { list ->
                availableMeasurements = list
                if (selectedMeasurementId == null && list.isNotEmpty()) {
                    selectedMeasurementId = list.first().id
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TailorTopBar(
                title = if (orderIdToEdit == null) "ثبت سفارش جدید" else "ویرایش سفارش",
                subtitle = "محاسبه خودکار مالی و ثبت اندازه‌ها",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "مبلغ باقیمانده: ${CurrencyFormatter.format(remainingAmount, currency)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (remainingAmount > 0) DebtRed else PaidGreen
                            )
                        )
                        Text(
                            text = "قیمت کل: ${CurrencyFormatter.format(totalAmount, currency)}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }

                    Button(
                        onClick = {
                            if (selectedCustomer == null) {
                                scope.launch { snackbarHostState.showSnackbar("لطفاً ابتدا مشتری را انتخاب کنید!") }
                                return@Button
                            }
                            if (orderItems.isEmpty()) {
                                scope.launch { snackbarHostState.showSnackbar("حداقل یک قلم لباس به سفارش اضافه کنید!") }
                                return@Button
                            }

                            val orderEntity = OrderEntity(
                                orderNumber = orderNumber.trim(),
                                customerId = selectedCustomer!!.id,
                                orderType = orderType.trim(),
                                description = description.trim(),
                                registrationDateShamsi = registrationDate.trim(),
                                deliveryDateShamsi = deliveryDate.trim(),
                                status = OrderStatus.PENDING,
                                totalAmount = totalAmount,
                                advancePayment = advancePayment,
                                remainingAmount = remainingAmount,
                                specialNotes = specialNotes.trim(),
                                measurementId = selectedMeasurementId
                            )

                            val itemsList = orderItems.map {
                                OrderItemEntity(
                                    orderId = 0L,
                                    clothingType = it.clothingType,
                                    quantity = it.quantity,
                                    unitPrice = it.unitPrice,
                                    notes = it.notes
                                )
                            }

                            viewModel.createOrder(
                                order = orderEntity,
                                items = itemsList,
                                initialPayment = advancePayment,
                                paymentMethod = selectedPaymentMethod,
                                onDone = { newOrderId ->
                                    viewModel.navigateTo(ScreenDestination.OrderDetail(newOrderId))
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TailorNavy,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_submit_order")
                    ) {
                        Text("ثبت و صدور قبض", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // --- 1. Customer Selection ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "مشتری سفارش *",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TailorNavy
                                )
                            )

                            OutlinedButton(
                                onClick = { showQuickAddCustomer = true },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ثبت مشتری جدید", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Box {
                            OutlinedTextField(
                                value = selectedCustomer?.let { "${it.fullName} (${it.phone})" } ?: "انتخاب مشتری...",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.clickable { showCustomerPicker = true }
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showCustomerPicker = true }
                                    .testTag("select_customer_dropdown")
                            )

                            DropdownMenu(
                                expanded = showCustomerPicker,
                                onDismissRequest = { showCustomerPicker = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                if (customers.isEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("هنوز هیچ مشتری ثبت نشده است") },
                                        onClick = { showCustomerPicker = false }
                                    )
                                } else {
                                    customers.forEach { cust ->
                                        DropdownMenuItem(
                                            text = {
                                                Column {
                                                    Text(cust.fullName, fontWeight = FontWeight.Bold)
                                                    Text(cust.phone, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            },
                                            onClick = {
                                                selectedCustomer = cust
                                                showCustomerPicker = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- 2. Order Details & Dates ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "اطلاعات کلی سفارش",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TailorNavy
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = orderNumber,
                                onValueChange = { orderNumber = it },
                                label = { Text("شماره سفارش / قبض") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = orderType,
                                onValueChange = { orderType = it },
                                label = { Text("نوع کلی سفارش") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("توضیحات مدل، پارچه و رنگ") },
                            placeholder = { Text("مثال: فاستونی طوسی انگلیسی، آستر ابریشم، دو دکمه") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = registrationDate,
                                onValueChange = { registrationDate = it },
                                label = { Text("تاریخ ثبت (شمسی)") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = deliveryDate,
                                onValueChange = { deliveryDate = it },
                                label = { Text("موعد تحویل (شمسی) *") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // --- 3. Order Items (امکان ثبت چند لباس در یک سفارش) ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "اقلام سفارش (${orderItems.size} قلم)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TailorNavy
                                )
                            )

                            OutlinedButton(
                                onClick = {
                                    orderItems.add(TempOrderItem("پیراهن", 1, 1500L, ""))
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("افزودن لباس", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        orderItems.forEachIndexed { index, item ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "قلم شماره ${index + 1}",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
                                    )
                                    if (orderItems.size > 1) {
                                        IconButton(
                                            onClick = { orderItems.removeAt(index) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف قلم", tint = DebtRed, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = item.clothingType,
                                        onValueChange = { item.clothingType = it },
                                        label = { Text("نوع لباس") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    OutlinedTextField(
                                        value = item.quantity.toString(),
                                        onValueChange = { item.quantity = it.toIntOrNull() ?: 1 },
                                        label = { Text("تعداد") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(0.7f)
                                    )
                                    OutlinedTextField(
                                        value = item.unitPrice.toString(),
                                        onValueChange = { item.unitPrice = it.toLongOrNull() ?: 0L },
                                        label = { Text("قیمت واحد") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.1f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = item.notes,
                                    onValueChange = { item.notes = it },
                                    label = { Text("توضیحات و مدل این لباس (اختیاری)") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            // --- 4. Linked Measurement Set ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Straighten, contentDescription = null, tint = TailorNavy)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "اندازه‌های مرتبط با سفارش",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TailorNavy
                                    )
                                )
                            }

                            if (selectedCustomer != null) {
                                OutlinedButton(
                                    onClick = { showAddMeasurementDialog = true },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("ثبت اندازه جدید", fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (selectedCustomer == null) {
                            Text(
                                text = "برای مشاهده یا انتخاب اندازه‌ها ابتدا مشتری را انتخاب نمایید.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        } else if (availableMeasurements.isEmpty()) {
                            Text(
                                text = "هنوز اندازه‌ای برای این مشتری ثبت نشده است. می‌توانید با دکمه بالا اندازه جدید ثبت کنید.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        } else {
                            Text(
                                text = "انتخاب مجموعه اندازه این سفارش:",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                availableMeasurements.forEach { m ->
                                    val isSelected = selectedMeasurementId == m.id
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) TailorNavy.copy(alpha = 0.08f) else Color.Transparent)
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) TailorGoldDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { selectedMeasurementId = m.id }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(m.title, fontWeight = FontWeight.Bold, color = TailorNavy)
                                            Text(
                                                text = "قد: ${m.shirtLength} | سینه: ${m.chest} | شانه: ${m.shoulder} | شلوار: ${m.pantsLength}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .size(10.dp)
                                                    .clip(CircleShape)
                                                    .background(TailorGoldDark)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- 5. Financial & Advance Payment ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "محاسبات مالی و پیش‌پرداخت",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TailorNavy
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = totalAmount.toString(),
                                onValueChange = {
                                    manualTotalOverride = it.toLongOrNull()
                                },
                                label = { Text("قیمت کل سفارش ($currency)") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = advancePaymentText,
                                onValueChange = { advancePaymentText = it },
                                label = { Text("پیش‌پرداخت ($currency)") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Payment method for advance payment
                        Text(
                            text = "روش پرداخت پیش‌پرداخت:",
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            paymentMethods.forEach { method ->
                                val isSelected = selectedPaymentMethod == method
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) TailorNavy else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { selectedPaymentMethod = method }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = method,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = specialNotes,
                            onValueChange = { specialNotes = it },
                            label = { Text("یادداشت اختصاصی سفارش (اختیاری)") },
                            shape = RoundedCornerShape(8.dp),
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }

    // Quick Add Customer Dialog
    if (showQuickAddCustomer) {
        AddEditCustomerDialog(
            customer = null,
            onDismiss = { showQuickAddCustomer = false },
            onSave = { newCust ->
                viewModel.saveCustomer(
                    customer = newCust,
                    onSuccess = { newId ->
                        showQuickAddCustomer = false
                        selectedCustomer = newCust.copy(id = newId)
                    },
                    onDuplicatePhone = {
                        scope.launch { snackbarHostState.showSnackbar("مشتری با این شماره تماس قبلاً ثبت شده است!") }
                    }
                )
            }
        )
    }

    // Add measurement dialog
    if (showAddMeasurementDialog && selectedCustomer != null) {
        AddEditMeasurementDialog(
            customerId = selectedCustomer!!.id,
            existingMeasurement = null,
            onDismiss = { showAddMeasurementDialog = false },
            onSave = { m ->
                viewModel.saveMeasurement(m) {
                    showAddMeasurementDialog = false
                    selectedMeasurementId = it
                }
            }
        )
    }
}
