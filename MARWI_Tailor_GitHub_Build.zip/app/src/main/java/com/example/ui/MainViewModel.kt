package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.CustomerEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.MeasurementEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.OrderWithCustomerInfo
import com.example.data.local.PaymentEntity
import com.example.data.local.ShopSettingsEntity
import com.example.data.repository.TailorRepository
import com.example.utils.PersianDateHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class ScreenDestination {
    object Dashboard : ScreenDestination()
    object Customers : ScreenDestination()
    data class CustomerDetail(val customerId: Long) : ScreenDestination()
    object Orders : ScreenDestination()
    data class OrderDetail(val orderId: Long) : ScreenDestination()
    data class AddEditOrder(val customerId: Long? = null, val orderId: Long? = null) : ScreenDestination()
    object Finance : ScreenDestination()
    object More : ScreenDestination()
    object OverdueOrders : ScreenDestination()
    object ShopSettings : ScreenDestination()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = TailorRepository(database.tailorDao())

    // --- Navigation ---
    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Dashboard)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf<ScreenDestination>()

    fun navigateTo(destination: ScreenDestination) {
        if (_currentScreen.value != destination) {
            screenBackStack.add(_currentScreen.value)
            _currentScreen.value = destination
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.isNotEmpty()) {
            _currentScreen.value = screenBackStack.removeAt(screenBackStack.lastIndex)
            return true
        }
        return false
    }

    // --- Search & Filters ---
    val customerSearchQuery = MutableStateFlow("")
    val orderSearchQuery = MutableStateFlow("")
    val orderStatusFilter = MutableStateFlow("ALL")

    // --- Data Streams ---
    val allCustomers = repository.allCustomers
        .combine(customerSearchQuery) { list, query ->
            if (query.isBlank()) list
            else list.filter {
                it.fullName.contains(query, ignoreCase = true) || it.phone.contains(query)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrdersWithCustomer = repository.allOrdersWithCustomer
        .combine(orderStatusFilter) { list, status ->
            if (status == "ALL") list
            else list.filter { it.status == status }
        }.combine(orderSearchQuery) { list, query ->
            if (query.isBlank()) list
            else list.filter {
                it.orderNumber.contains(query, ignoreCase = true) ||
                        it.customerName.contains(query, ignoreCase = true) ||
                        it.customerPhone.contains(query) ||
                        it.orderType.contains(query, ignoreCase = true)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shopSettings: StateFlow<ShopSettingsEntity> = repository.shopSettings
        .combine(MutableStateFlow(Unit)) { settings, _ ->
            settings ?: ShopSettingsEntity()
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            ShopSettingsEntity()
        )

    // --- Dashboard Aggregates ---
    val totalCustomersCount = repository.totalCustomersCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val pendingOrdersCount = repository.getOrderCountByStatus(OrderStatus.PENDING)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val inProgressOrdersCount = repository.getOrderCountByStatus(OrderStatus.IN_PROGRESS)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val readyOrdersCount = repository.getOrderCountByStatus(OrderStatus.READY)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val deliveredOrdersCount = repository.getOrderCountByStatus(OrderStatus.DELIVERED)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalDebt = repository.totalDebt
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val todayIncome = repository.getTodayIncome(PersianDateHelper.todayFormatted())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Near delivery orders (upcoming in next 3 days or today, and not delivered/cancelled)
    val upcomingOrders = repository.allOrdersWithCustomer
        .combine(MutableStateFlow(Unit)) { orders, _ ->
            val today = PersianDateHelper.today()
            orders.filter { order ->
                (order.status == OrderStatus.PENDING || order.status == OrderStatus.IN_PROGRESS || order.status == OrderStatus.READY) &&
                        PersianDateHelper.isNearDelivery(order.deliveryDateShamsi, today)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Overdue orders (past delivery date and not delivered/cancelled)
    val overdueOrders = repository.allOrdersWithCustomer
        .combine(MutableStateFlow(Unit)) { orders, _ ->
            val todayStr = PersianDateHelper.todayFormatted()
            orders.filter { order ->
                order.status != OrderStatus.DELIVERED &&
                        order.status != OrderStatus.CANCELLED &&
                        PersianDateHelper.isOverdue(order.deliveryDateShamsi, todayStr)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Customer Operations ---
    fun saveCustomer(
        customer: CustomerEntity,
        onSuccess: (Long) -> Unit,
        onDuplicatePhone: () -> Unit
    ) {
        viewModelScope.launch {
            val existing = repository.findCustomerByPhone(customer.phone)
            if (existing != null && existing.id != customer.id) {
                onDuplicatePhone()
            } else {
                val id = repository.saveCustomer(customer)
                onSuccess(id)
            }
        }
    }

    fun deleteCustomer(customer: CustomerEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            onDone()
        }
    }

    // --- Measurement Operations ---
    fun saveMeasurement(measurement: MeasurementEntity, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.saveMeasurement(measurement)
            onDone(id)
        }
    }

    fun deleteMeasurement(measurement: MeasurementEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteMeasurement(measurement)
            onDone()
        }
    }

    // --- Order Operations ---
    fun createOrder(
        order: OrderEntity,
        items: List<OrderItemEntity>,
        initialPayment: Long,
        paymentMethod: String,
        onDone: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.createOrder(order, items, initialPayment, paymentMethod)
            onDone(id)
        }
    }

    fun updateOrderStatus(orderId: Long, status: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, status)
        }
    }

    fun deleteOrder(order: OrderEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteOrder(order)
            onDone()
        }
    }

    // --- Financial Operations ---
    fun addPayment(
        orderId: Long,
        customerId: Long,
        amount: Long,
        paymentMethod: String,
        notes: String,
        paymentDate: String = PersianDateHelper.todayFormatted(),
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.addPayment(
                orderId = orderId,
                customerId = customerId,
                amount = amount,
                paymentDateShamsi = paymentDate,
                paymentMethod = paymentMethod,
                notes = notes
            )
            onDone()
        }
    }

    fun deletePayment(payment: PaymentEntity) {
        viewModelScope.launch {
            repository.deletePayment(payment)
        }
    }

    fun addExpense(expense: ExpenseEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.addExpense(expense)
            onDone()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    // --- Settings & Backup Operations ---
    fun updateShopSettings(settings: ShopSettingsEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveShopSettings(settings)
            onDone()
        }
    }
}
