package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OrderWithCustomerInfo
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LuxuryStatCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.StatusInProgress
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusReady
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.ui.theme.TailorNavyDark
import com.example.ui.theme.TailorNavyLight
import com.example.utils.CurrencyFormatter
import com.example.utils.PersianDateHelper

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()
    val totalCustomers by viewModel.totalCustomersCount.collectAsStateWithLifecycle()
    val pendingCount by viewModel.pendingOrdersCount.collectAsStateWithLifecycle()
    val inProgressCount by viewModel.inProgressOrdersCount.collectAsStateWithLifecycle()
    val readyCount by viewModel.readyOrdersCount.collectAsStateWithLifecycle()
    val deliveredCount by viewModel.deliveredOrdersCount.collectAsStateWithLifecycle()
    val totalDebt by viewModel.totalDebt.collectAsStateWithLifecycle()
    val todayIncome by viewModel.todayIncome.collectAsStateWithLifecycle()
    val upcomingOrders by viewModel.upcomingOrders.collectAsStateWithLifecycle()
    val overdueOrders by viewModel.overdueOrders.collectAsStateWithLifecycle()
    val allOrders by viewModel.allOrdersWithCustomer.collectAsStateWithLifecycle()

    val currency = settings.currencyUnit
    val todayDateFormatted = PersianDateHelper.todayReadableWithDayName()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Luxury Hero Banner ---
        item {
            DashboardHeroBanner(
                shopName = settings.shopName,
                tailorName = settings.tailorName,
                dateString = todayDateFormatted,
                overdueCount = overdueOrders.size,
                onOverdueClick = { viewModel.navigateTo(ScreenDestination.OverdueOrders) }
            )
        }

        // --- 2. Quick Actions ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.navigateTo(ScreenDestination.AddEditOrder()) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("dashboard_btn_new_order"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TailorNavy,
                        contentColor = Color.White
                    )
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = TailorGold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "ثبت سفارش جدید", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.Customers) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("dashboard_btn_new_customer"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TailorNavy
                    )
                ) {
                    Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, tint = TailorNavy)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "ثبت مشتری جدید", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }

        // --- 3. Key Financial & Operational Stats ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionHeader(title = "خلاصه مالی و آماری")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LuxuryStatCard(
                        title = "دریافتی امروز",
                        value = CurrencyFormatter.format(todayIncome ?: 0L, currency),
                        icon = Icons.Default.Payments,
                        iconColor = PaidGreen,
                        modifier = Modifier.weight(1f)
                    )
                    LuxuryStatCard(
                        title = "مجموع طلب (بدهی)",
                        value = CurrencyFormatter.format(totalDebt ?: 0L, currency),
                        icon = Icons.Default.PriceCheck,
                        iconColor = DebtRed,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LuxuryStatCard(
                        title = "کل مشتریان",
                        value = "$totalCustomers نفر",
                        icon = Icons.Default.People,
                        iconColor = TailorNavyLight,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(ScreenDestination.Customers) }
                    )
                    LuxuryStatCard(
                        title = "سفارش‌های جدید",
                        value = "$pendingCount مورد",
                        icon = Icons.Default.HourglassTop,
                        iconColor = StatusPending,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            viewModel.orderStatusFilter.value = "PENDING"
                            viewModel.navigateTo(ScreenDestination.Orders)
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LuxuryStatCard(
                        title = "در حال دوخت",
                        value = "$inProgressCount مورد",
                        icon = Icons.Default.ContentCut,
                        iconColor = StatusInProgress,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            viewModel.orderStatusFilter.value = "IN_PROGRESS"
                            viewModel.navigateTo(ScreenDestination.Orders)
                        }
                    )
                    LuxuryStatCard(
                        title = "آماده تحویل",
                        value = "$readyCount مورد",
                        icon = Icons.Default.CheckCircle,
                        iconColor = StatusReady,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            viewModel.orderStatusFilter.value = "READY"
                            viewModel.navigateTo(ScreenDestination.Orders)
                        }
                    )
                }
            }
        }

        // --- 4. Upcoming Delivery Orders (سفارش‌های نزدیک به موعد تحویل) ---
        item {
            SectionHeader(
                title = "نزدیک به موعد تحویل (${upcomingOrders.size})",
                actionText = if (upcomingOrders.isNotEmpty()) "مشاهده همه" else null,
                onActionClick = {
                    viewModel.orderStatusFilter.value = "ALL"
                    viewModel.navigateTo(ScreenDestination.Orders)
                }
            )
        }

        if (upcomingOrders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = PaidGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "سفارشی برای تحویل در ۲ الی ۳ روز آینده وجود ندارد.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        } else {
            items(upcomingOrders.take(3)) { order ->
                UpcomingOrderCard(
                    order = order,
                    currency = currency,
                    onClick = { viewModel.navigateTo(ScreenDestination.OrderDetail(order.id)) }
                )
            }
        }

        // --- 5. Recent Orders (آخرین سفارش‌ها) ---
        item {
            SectionHeader(
                title = "آخرین سفارش‌ها",
                actionText = "فهرست کامل",
                onActionClick = {
                    viewModel.orderStatusFilter.value = "ALL"
                    viewModel.navigateTo(ScreenDestination.Orders)
                }
            )
        }

        if (allOrders.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.ContentCut,
                    title = "هنوز سفارشی ثبت نشده است",
                    description = "با دکمه زیر می‌توانید اولین سفارش خیاطی را ثبت کنید.",
                    actionButtonText = "ثبت سفارش جدید",
                    onActionClick = { viewModel.navigateTo(ScreenDestination.AddEditOrder()) }
                )
            }
        } else {
            items(allOrders.take(5)) { order ->
                DashboardOrderRow(
                    order = order,
                    currency = currency,
                    onClick = { viewModel.navigateTo(ScreenDestination.OrderDetail(order.id)) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun DashboardHeroBanner(
    shopName: String,
    tailorName: String,
    dateString: String,
    overdueCount: Int,
    onOverdueClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = TailorNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(TailorNavyDark, TailorNavy, TailorNavyLight)
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = shopName,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TailorGold
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "مدیریت خیاطی مردانه • $tailorName",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(TailorGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCut,
                            contentDescription = null,
                            tint = TailorGold,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = TailorGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = dateString,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        )
                    }

                    if (overdueCount > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(DebtRed)
                                .clickable { onOverdueClick() }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$overdueCount سفارش معوق",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UpcomingOrderCard(
    order: OrderWithCustomerInfo,
    currency: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = order.customerName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(status = order.status)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${order.orderType} • شماره ${order.orderNumber}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = TailorGoldDark,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "تحویل: ${order.deliveryDateShamsi}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TailorNavy
                        )
                    )
                }
                if (order.remainingAmount > 0) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "مانده: ${CurrencyFormatter.format(order.remainingAmount, currency)}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = DebtRed,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardOrderRow(
    order: OrderWithCustomerInfo,
    currency: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = order.customerName,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${order.orderType} • ${order.orderNumber}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                StatusBadge(status = order.status)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = CurrencyFormatter.format(order.totalAmount, currency),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
    }
}
