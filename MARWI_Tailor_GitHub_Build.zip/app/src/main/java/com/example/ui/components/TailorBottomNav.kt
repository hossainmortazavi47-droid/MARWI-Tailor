package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScreenDestination
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.ui.theme.TailorNavyDark

enum class MainNavTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val destination: ScreenDestination,
    val testTag: String
) {
    HOME(
        title = "خانه",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        destination = ScreenDestination.Dashboard,
        testTag = "nav_tab_home"
    ),
    CUSTOMERS(
        title = "مشتریان",
        selectedIcon = Icons.Filled.People,
        unselectedIcon = Icons.Outlined.People,
        destination = ScreenDestination.Customers,
        testTag = "nav_tab_customers"
    ),
    ORDERS(
        title = "سفارش‌ها",
        selectedIcon = Icons.Filled.ContentCut,
        unselectedIcon = Icons.Outlined.ContentCut,
        destination = ScreenDestination.Orders,
        testTag = "nav_tab_orders"
    ),
    FINANCE(
        title = "مالی",
        selectedIcon = Icons.Filled.AccountBalanceWallet,
        unselectedIcon = Icons.Outlined.AccountBalanceWallet,
        destination = ScreenDestination.Finance,
        testTag = "nav_tab_finance"
    ),
    MORE(
        title = "بیشتر",
        selectedIcon = Icons.Filled.MoreHoriz,
        unselectedIcon = Icons.Outlined.MoreHoriz,
        destination = ScreenDestination.More,
        testTag = "nav_tab_more"
    )
}

@Composable
fun TailorBottomNavBar(
    currentDestination: ScreenDestination,
    onTabSelected: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        MainNavTab.values().forEach { tab ->
            val isSelected = when (tab) {
                MainNavTab.HOME -> currentDestination is ScreenDestination.Dashboard
                MainNavTab.CUSTOMERS -> currentDestination is ScreenDestination.Customers || currentDestination is ScreenDestination.CustomerDetail
                MainNavTab.ORDERS -> currentDestination is ScreenDestination.Orders || currentDestination is ScreenDestination.OrderDetail || currentDestination is ScreenDestination.AddEditOrder
                MainNavTab.FINANCE -> currentDestination is ScreenDestination.Finance
                MainNavTab.MORE -> currentDestination is ScreenDestination.More || currentDestination is ScreenDestination.ShopSettings || currentDestination is ScreenDestination.OverdueOrders
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab.destination) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                        contentDescription = tab.title,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = TailorNavyDark,
                    selectedTextColor = TailorNavy,
                    indicatorColor = TailorGold,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag(tab.testTag)
            )
        }
    }
}

@Composable
fun TailorNavigationRailBar(
    currentDestination: ScreenDestination,
    onTabSelected: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationRail(
        modifier = modifier.fillMaxHeight(),
        containerColor = MaterialTheme.colorScheme.surface,
        header = {
            Column(
                modifier = Modifier.padding(vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(TailorNavy),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ContentCut,
                        contentDescription = null,
                        tint = TailorGold,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "MARWI",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TailorNavy
                    )
                )
            }
        }
    ) {
        MainNavTab.values().forEach { tab ->
            val isSelected = when (tab) {
                MainNavTab.HOME -> currentDestination is ScreenDestination.Dashboard
                MainNavTab.CUSTOMERS -> currentDestination is ScreenDestination.Customers || currentDestination is ScreenDestination.CustomerDetail
                MainNavTab.ORDERS -> currentDestination is ScreenDestination.Orders || currentDestination is ScreenDestination.OrderDetail || currentDestination is ScreenDestination.AddEditOrder
                MainNavTab.FINANCE -> currentDestination is ScreenDestination.Finance
                MainNavTab.MORE -> currentDestination is ScreenDestination.More || currentDestination is ScreenDestination.ShopSettings || currentDestination is ScreenDestination.OverdueOrders
            }

            NavigationRailItem(
                selected = isSelected,
                onClick = { onTabSelected(tab.destination) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                        contentDescription = tab.title
                    )
                },
                label = { Text(tab.title, fontSize = 11.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = TailorNavyDark,
                    selectedTextColor = TailorNavy,
                    indicatorColor = TailorGold,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag(tab.testTag)
            )
        }
    }
}
