package com.example.ui.screens.customers

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CustomerEntity
import com.example.data.local.MeasurementEntity
import com.example.data.local.OrderEntity
import com.example.data.local.PaymentEntity
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.components.TailorConfirmDialog
import com.example.ui.components.TailorTopBar
import com.example.ui.screens.measurements.AddEditMeasurementDialog
import com.example.ui.theme.DebtRed
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.TailorGold
import com.example.ui.theme.TailorGoldDark
import com.example.ui.theme.TailorNavy
import com.example.utils.CurrencyFormatter

import androidx.compose.material3.ExperimentalMaterial3Api

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    customerId: Long,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val customer by viewModel.repository.getCustomerById(customerId).collectAsStateWithLifecycle(initialValue = null)
    val measurements by viewModel.repository.getMeasurementsForCustomer(customerId).collectAsStateWithLifecycle(initialValue = emptyList())
    val customerOrders by viewModel.repository.getOrdersForCustomer(customerId).collectAsStateWithLifecycle(initialValue = emptyList())
    val customerPayments by viewModel.repository.getPaymentsForCustomer(customerId).collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by viewModel.shopSettings.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showEditCustomerDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    var showMeasurementDialog by remember { mutableStateOf(false) }
    var measurementToEdit by remember { mutableStateOf<MeasurementEntity?>(null) }
    var measurementToDelete by remember { mutableStateOf<MeasurementEntity?>(null) }

    val currency = settings.currencyUnit
    val totalSpent = customerOrders.sumOf { it.totalAmount }
    val totalRemainingDebt = customerOrders.filter { it.status != "CANCELLED" }.sumOf { it.remainingAmount }

    Scaffold(
        topBar = {
            TailorTopBar(
                title = customer?.fullName ?: "مشخصات مشتری",
                subtitle = customer?.phone,
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    IconButton(
                        onClick = { showEditCustomerDialog = true },
                        modifier = Modifier.testTag("btn_edit_customer")
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "ویرایش مشتری", tint = TailorNavy)
                    }
                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.testTag("btn_delete_customer")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف مشتری", tint = DebtRed)
                    }
                }
            )
        }
    ) { padding ->
        if (customer == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("اطلاعات مشتری یافت نشد.")
            }
            return@Scaffold
        }

        val cust = customer!!

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Customer Header Card
            item {
                CustomerProfileCard(
                    customer = cust,
                    totalSpent = totalSpent,
                    totalDebt = totalRemainingDebt,
                    currency = currency,
                    onCallClick = {
                        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:${cust.phone}")
                        }
                        context.startActivity(dialIntent)
                    }
                )
            }

            // Quick Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.navigateTo(ScreenDestination.AddEditOrder(customerId = cust.id))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TailorNavy),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = TailorGold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("سفارش جدید", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            measurementToEdit = null
                            showMeasurementDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Straighten, contentDescription = null, tint = TailorNavy)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اندازه جدید", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Tabs for Measurements, Orders, Payments
            item {
                PrimaryTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = TailorNavy,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = { Text("اندازه‌ها (${measurements.size})", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = { Text("سفارش‌ها (${customerOrders.size})", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        text = { Text("پرداخت‌ها (${customerPayments.size})", fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> {
                    if (measurements.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Default.Straighten,
                                title = "اندازه‌ای برای این مشتری ثبت نشده",
                                description = "برای ثبت دور سینه، قد لباس، آستین، پتلون و سایر مشخصات کلیک کنید.",
                                actionButtonText = "ثبت اندازه جدید",
                                onActionClick = {
                                    measurementToEdit = null
                                    showMeasurementDialog = true
                                }
                            )
                        }
                    } else {
                        items(measurements, key = { it.id }) { measurement ->
                            MeasurementCard(
                                measurement = measurement,
                                onEdit = {
                                    measurementToEdit = measurement
                                    showMeasurementDialog = true
                                },
                                onDelete = {
                                    measurementToDelete = measurement
                                }
                            )
                        }
                    }
                }
                1 -> {
                    if (customerOrders.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Default.ContentCut,
                                title = "هنوز سفارشی برای این مشتری ثبت نشده",
                                description = "می‌توانید همین حالا اولین سفارش را ثبت کنید.",
                                actionButtonText = "ثبت سفارش جدید",
                                onActionClick = {
                                    viewModel.navigateTo(ScreenDestination.AddEditOrder(customerId = cust.id))
                                }
                            )
                        }
                    } else {
                        items(customerOrders, key = { it.id }) { order ->
                            CustomerOrderRow(
                                order = order,
                                currency = currency,
                                onClick = {
                                    viewModel.navigateTo(ScreenDestination.OrderDetail(order.id))
                                }
                            )
                        }
                    }
                }
                2 -> {
                    if (customerPayments.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Default.Payments,
                                title = "پرداختی ثبت نشده است",
                                description = "پرداخت‌ها هنگام ثبت سفارش یا در بخش جزئیات سفارش ثبت می‌شوند."
                            )
                        }
                    } else {
                        items(customerPayments, key = { it.id }) { payment ->
                            CustomerPaymentRow(payment = payment, currency = currency)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    // Edit customer dialog
    if (showEditCustomerDialog) {
        AddEditCustomerDialog(
            customer = customer,
            onDismiss = { showEditCustomerDialog = false },
            onSave = { updated ->
                viewModel.saveCustomer(
                    customer = updated,
                    onSuccess = { showEditCustomerDialog = false },
                    onDuplicatePhone = { /* handled */ }
                )
            }
        )
    }

    // Delete customer dialog
    TailorConfirmDialog(
        show = showDeleteConfirmDialog,
        title = "حذف مشتری",
        message = "آیا از حذف «${customer?.fullName}» اطمینان دارید؟ تمامی سفارش‌ها، اندازه‌ها و پرداخت‌های این مشتری نیز حذف خواهند شد.",
        confirmButtonText = "بله، حذف کن",
        isDestructive = true,
        onConfirm = {
            customer?.let {
                viewModel.deleteCustomer(it) {
                    showDeleteConfirmDialog = false
                    viewModel.navigateBack()
                }
            }
        },
        onDismiss = { showDeleteConfirmDialog = false }
    )

    // Add / Edit Measurement Dialog
    if (showMeasurementDialog) {
        AddEditMeasurementDialog(
            customerId = customerId,
            existingMeasurement = measurementToEdit,
            onDismiss = { showMeasurementDialog = false },
            onSave = { measurement ->
                viewModel.saveMeasurement(measurement) {
                    showMeasurementDialog = false
                }
            }
        )
    }

    // Delete measurement confirm
    TailorConfirmDialog(
        show = measurementToDelete != null,
        title = "حذف اندازه",
        message = "آیا از حذف اندازه «${measurementToDelete?.title}» مطمئن هستید؟",
        confirmButtonText = "حذف اندازه",
        isDestructive = true,
        onConfirm = {
            measurementToDelete?.let {
                viewModel.deleteMeasurement(it) {
                    measurementToDelete = null
                }
            }
        },
        onDismiss = { measurementToDelete = null }
    )
}

@Composable
fun CustomerProfileCard(
    customer: CustomerEntity,
    totalSpent: Long,
    totalDebt: Long,
    currency: String,
    onCallClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(TailorNavy),
                    contentAlignment = Alignment.Center
                ) {
                    val initials = customer.fullName.split(" ").take(2).mapNotNull { it.firstOrNull()?.toString() }.joinToString(" ")
                    Text(
                        text = if (initials.isNotBlank()) initials else "م",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TailorGold
                        )
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = customer.fullName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = customer.phone,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    if (customer.address.isNotBlank()) {
                        Text(
                            text = customer.address,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                IconButton(
                    onClick = onCallClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(PaidGreen.copy(alpha = 0.12f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "تماس با مشتری",
                        tint = PaidGreen
                    )
                }
            }

            if (customer.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TailorGold.copy(alpha = 0.1f))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "یادداشت: ${customer.notes}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TailorNavy,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Debt & Total balance
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "مجموع خرید",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = CurrencyFormatter.format(totalSpent, currency),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "باقیمانده بدهی",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = CurrencyFormatter.format(totalDebt, currency),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (totalDebt > 0) DebtRed else PaidGreen
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun MeasurementCard(
    measurement: MeasurementEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Straighten,
                        contentDescription = null,
                        tint = TailorNavy,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = measurement.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TailorNavy
                        )
                    )
                    if (measurement.dateShamsi.isNotBlank()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "(${measurement.dateShamsi})",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "ویرایش", tint = TailorGoldDark, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = DebtRed, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Upper body measurements grid
            Text(
                text = "بالاتنه / پیراهن:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MeasureTag("قد", measurement.shirtLength)
                MeasureTag("سینه", measurement.chest)
                MeasureTag("کمر", measurement.waist)
                MeasureTag("شکم", measurement.stomach)
                MeasureTag("باسن", measurement.hips)
                MeasureTag("شانه", measurement.shoulder)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MeasureTag("آستین", measurement.sleeveLength)
                MeasureTag("بازو", measurement.armBicep)
                MeasureTag("مچ", measurement.wrist)
                MeasureTag("یقه", measurement.collar)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Lower body measurements grid
            Text(
                text = "پایین‌تنه / پتلون:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TailorNavy)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MeasureTag("قد شلوار", measurement.pantsLength)
                MeasureTag("کمر شلوار", measurement.pantsWaist)
                MeasureTag("ران", measurement.thigh)
                MeasureTag("زانو", measurement.knee)
                MeasureTag("دمپا", measurement.pantsCuff)
                MeasureTag("فاق", measurement.crotch)
            }

            if (measurement.customNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "یادداشت برش: ${measurement.customNotes}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                )
            }
        }
    }
}

@Composable
private fun MeasureTag(label: String, value: String) {
    if (value.isBlank()) return
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun CustomerOrderRow(
    order: OrderEntity,
    currency: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${order.orderType} • ${order.orderNumber}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ثبت: ${order.registrationDateShamsi} | تحویل: ${order.deliveryDateShamsi}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                StatusBadge(status = order.status)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = CurrencyFormatter.format(order.totalAmount, currency),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
fun CustomerPaymentRow(
    payment: PaymentEntity,
    currency: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "${payment.paymentMethod} • تاریخ ${payment.paymentDateShamsi}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                if (payment.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = payment.notes,
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }

            Text(
                text = "+ ${CurrencyFormatter.format(payment.amount, currency)}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = PaidGreen
                )
            )
        }
    }
}
