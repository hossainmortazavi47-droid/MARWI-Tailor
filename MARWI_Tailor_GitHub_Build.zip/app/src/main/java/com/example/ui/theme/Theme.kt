package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TailorGold,
    onPrimary = TailorNavyDark,
    primaryContainer = TailorNavySurface,
    onPrimaryContainer = TailorGoldLight,
    secondary = TailorGoldLight,
    onSecondary = TailorNavyDark,
    secondaryContainer = TailorNavySurface,
    onSecondaryContainer = TailorGold,
    tertiary = Color(0xFF81A4CD),
    background = TailorDarkBackground,
    onBackground = TailorTextPrimaryDark,
    surface = TailorDarkSurface,
    onSurface = TailorTextPrimaryDark,
    surfaceVariant = TailorDarkCard,
    onSurfaceVariant = TailorTextSecondaryDark,
    outline = TailorDarkCardBorder,
    error = Color(0xFFF87171)
)

private val LightColorScheme = lightColorScheme(
    primary = TailorNavy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3ECF7),
    onPrimaryContainer = TailorNavyDark,
    secondary = TailorGoldDark,
    onSecondary = Color.White,
    secondaryContainer = TailorGoldContainer,
    onSecondaryContainer = Color(0xFF5D4513),
    tertiary = TailorGold,
    background = TailorIvory,
    onBackground = TailorTextPrimaryLight,
    surface = TailorSurfaceLight,
    onSurface = TailorTextPrimaryLight,
    surfaceVariant = Color(0xFFEFECE3),
    onSurfaceVariant = TailorTextSecondaryLight,
    outline = TailorCardBorderLight,
    error = DebtRed
)

@Composable
fun MarwiTailorTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
