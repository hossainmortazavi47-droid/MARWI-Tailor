package com.example.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.TailorTopBar
import com.example.ui.theme.TailorNavy
import kotlinx.coroutines.launch

@Composable
fun ShopSettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentSettings by viewModel.shopSettings.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var shopName by remember(currentSettings) { mutableStateOf(currentSettings.shopName) }
    var tailorName by remember(currentSettings) { mutableStateOf(currentSettings.tailorName) }
    var phone by remember(currentSettings) { mutableStateOf(currentSettings.phone) }
    var address by remember(currentSettings) { mutableStateOf(currentSettings.address) }
    var currencyUnit by remember(currentSettings) { mutableStateOf(currentSettings.currencyUnit) }
    var receiptFooterNote by remember(currentSettings) { mutableStateOf(currentSettings.receiptFooterNote) }

    Scaffold(
        topBar = {
            TailorTopBar(
                title = "تنظیمات کارگاه و خیاطی",
                subtitle = "شخصی‌سازی مشخصات در فاکتور و رسیدها",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Button(
                onClick = {
                    val updated = currentSettings.copy(
                        shopName = shopName.trim(),
                        tailorName = tailorName.trim(),
                        phone = phone.trim(),
                        address = address.trim(),
                        currencyUnit = currencyUnit.trim().ifEmpty { "افغانی" },
                        receiptFooterNote = receiptFooterNote.trim()
                    )
                    viewModel.updateShopSettings(updated) {
                        scope.launch {
                            snackbarHostState.showSnackbar("تنظیمات با موفقیت ذخیره شد.")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TailorNavy, contentColor = Color.White)
            ) {
                Text("ذخیره تغییرات", fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "مشخصات کارگاه خیاطی",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TailorNavy
                            )
                        )

                        OutlinedTextField(
                            value = shopName,
                            onValueChange = { shopName = it },
                            label = { Text("نام کارگاه خیاطی") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = tailorName,
                            onValueChange = { tailorName = it },
                            label = { Text("نام استاد خیاط / مدیر") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("شماره تماس خیاطی") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("نشانی کارگاه / دکان") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = currencyUnit,
                            onValueChange = { currencyUnit = it },
                            label = { Text("واحد پولی (مثال: افغانی، تومان، ریال)") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = receiptFooterNote,
                            onValueChange = { receiptFooterNote = it },
                            label = { Text("متن پایانی قبض سفارش (تذکرات تحویل)") },
                            minLines = 2,
                            maxLines = 4,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}
