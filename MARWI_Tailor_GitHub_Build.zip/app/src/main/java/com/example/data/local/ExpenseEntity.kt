package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "expenses",
    indices = [Index(value = ["expenseDateShamsi"])]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Long,
    val category: String = "سایر", // پارچه و آستر، ملحقات و دکمه، کرایه و برق، دستمزد، ابزار و تعمیر، سایر
    val expenseDateShamsi: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
