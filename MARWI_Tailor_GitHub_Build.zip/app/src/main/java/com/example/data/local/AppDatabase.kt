package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.utils.PersianDateHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        CustomerEntity::class,
        MeasurementEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
        PaymentEntity::class,
        ExpenseEntity::class,
        ShopSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun tailorDao(): TailorDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "marwi_tailor_pro.db"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        scope.launch {
                            INSTANCE?.let { database ->
                                seedInitialData(database.tailorDao())
                            }
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedInitialData(dao: TailorDao) {
            // Seed default settings
            dao.insertOrUpdateSettings(
                ShopSettingsEntity(
                    id = 1,
                    shopName = "خیاطی مردانه ماروی (MARWI)",
                    tailorName = "استاد احمد ماروی",
                    phone = "0799123456",
                    address = "کابل، شهر نو، مرکز تجارتی خیاطان، طبقه دوم، پلاک ۲۴",
                    currencyUnit = "افغانی",
                    receiptFooterNote = "با تشکر از انتخاب شما. پرو نهایی و تحویل سفارش با ارائه این قبض صورت می‌پذیرد."
                )
            )

            val today = PersianDateHelper.todayFormatted()
            val tomorrow = PersianDateHelper.addDaysToToday(1)
            val nextWeek = PersianDateHelper.addDaysToToday(6)

            // Seed 3 realistic customers
            val c1Id = dao.insertCustomer(
                CustomerEntity(
                    fullName = "حاجی محمد ناصر غفوری",
                    phone = "0788112233",
                    address = "وزیر اکبرخان، سرک ۱۵",
                    notes = "مشتری قدیمی و بسیار حساس به ظرافت دوخت سرآستین"
                )
            )
            val c2Id = dao.insertCustomer(
                CustomerEntity(
                    fullName = "انجنیر احمد ولی حسینی",
                    phone = "0777445566",
                    address = "کارته ۳، جنب پوهنتون کابل",
                    notes = "مدل دریشی ایتالیایی دو دکمه می‌پسندد"
                )
            )
            val c3Id = dao.insertCustomer(
                CustomerEntity(
                    fullName = "محمد یاسر صمیمی",
                    phone = "0700889900",
                    address = "خیرخانه، حصه اول",
                    notes = "اندازه‌گیری دقیق پیراهن تنبان عید"
                )
            )

            // Seed Measurements
            val m1Id = dao.insertMeasurement(
                MeasurementEntity(
                    customerId = c1Id,
                    title = "اندازه دریشی رسمی مجلسی",
                    dateShamsi = today,
                    shirtLength = "۷۸",
                    chest = "۱۰۴",
                    waist = "۹۶",
                    stomach = "۹۸",
                    hips = "۱۰۸",
                    shoulder = "۴۶",
                    sleeveLength = "۶۴",
                    armBicep = "۳۶",
                    wrist = "۲۶",
                    collar = "۴۲",
                    pantsLength = "۱۰۲",
                    pantsWaist = "۹۲",
                    thigh = "۶۲",
                    knee = "۴۶",
                    pantsCuff = "۳۸",
                    crotch = "۳۰",
                    customNotes = "جیب بغل شیب‌دار و چاک دوبل پشت کت"
                )
            )

            val m2Id = dao.insertMeasurement(
                MeasurementEntity(
                    customerId = c2Id,
                    title = "اندازه پیراهن و واسکت",
                    dateShamsi = today,
                    shirtLength = "۱۰۰",
                    chest = "۹۸",
                    waist = "۸۸",
                    stomach = "۸۸",
                    hips = "۱۰۰",
                    shoulder = "۴۴",
                    sleeveLength = "۶۲",
                    armBicep = "۳۳",
                    wrist = "۲۴",
                    collar = "۴۰",
                    pantsLength = "۹۸",
                    pantsWaist = "۸۴",
                    thigh = "۵۸",
                    knee = "۴۲",
                    pantsCuff = "۳۶",
                    crotch = "۲۸",
                    customNotes = "یقه دیپلماتیک (مندرین) و آستین دکمه‌دار"
                )
            )

            // Seed Orders
            val o1Id = dao.insertOrder(
                OrderEntity(
                    orderNumber = "ORD-101",
                    customerId = c1Id,
                    orderType = "دریشی کامل (کت، واسکت و پتلون)",
                    description = "پارچه فاستونی طوسی انگلیسی، آستر ابریشمی طلایی",
                    registrationDateShamsi = today,
                    deliveryDateShamsi = tomorrow,
                    status = OrderStatus.IN_PROGRESS,
                    totalAmount = 8500L,
                    advancePayment = 4000L,
                    remainingAmount = 4500L,
                    specialNotes = "پرو اول انجام شده، آماده‌سازی برای آسترکشی نهایی",
                    measurementId = m1Id
                )
            )
            dao.insertOrderItems(
                listOf(
                    OrderItemEntity(orderId = o1Id, clothingType = "دریشی", quantity = 1, unitPrice = 7000L, notes = "کت تک‌چاک و شلوار راسته"),
                    OrderItemEntity(orderId = o1Id, clothingType = "واسکت", quantity = 1, unitPrice = 1500L, notes = "واسکټ ۶ دکمه")
                )
            )
            dao.insertPayment(
                PaymentEntity(
                    orderId = o1Id,
                    customerId = c1Id,
                    amount = 4000L,
                    paymentDateShamsi = today,
                    paymentMethod = "نقدی",
                    notes = "پیش‌پرداخت نقدی هنگام سفارش"
                )
            )

            val o2Id = dao.insertOrder(
                OrderEntity(
                    orderNumber = "ORD-102",
                    customerId = c2Id,
                    orderType = "پیراهن و تنبان افغانی",
                    description = "پارچه کتان شیری درجه یک، دست‌دوزی یقه و دمپای آستین",
                    registrationDateShamsi = today,
                    deliveryDateShamsi = nextWeek,
                    status = OrderStatus.PENDING,
                    totalAmount = 2500L,
                    advancePayment = 1000L,
                    remainingAmount = 1500L,
                    specialNotes = "برش در نوبت، سوزن‌دوزی ظریف خامک‌دوزی روی یقه",
                    measurementId = m2Id
                )
            )
            dao.insertOrderItems(
                listOf(
                    OrderItemEntity(orderId = o2Id, clothingType = "پیراهن", quantity = 1, unitPrice = 1800L, notes = "یقه قاقاف دکمه‌مخفی"),
                    OrderItemEntity(orderId = o2Id, clothingType = "پتلون", quantity = 1, unitPrice = 700L, notes = "تنبان چین‌دار با بند کتان")
                )
            )
            dao.insertPayment(
                PaymentEntity(
                    orderId = o2Id,
                    customerId = c2Id,
                    amount = 1000L,
                    paymentDateShamsi = today,
                    paymentMethod = "حواله بانکی",
                    notes = "انتقال بانکی پیش‌پرداخت"
                )
            )

            val o3Id = dao.insertOrder(
                OrderEntity(
                    orderNumber = "ORD-103",
                    customerId = c3Id,
                    orderType = "دو دست پیراهن و پتلون کتان",
                    description = "رنگ سرمه‌ای و خاکستری تیره",
                    registrationDateShamsi = today,
                    deliveryDateShamsi = today,
                    status = OrderStatus.READY,
                    totalAmount = 4000L,
                    advancePayment = 4000L,
                    remainingAmount = 0L,
                    specialNotes = "دوخت و اتو بخار تکمیل شده، منتظر مراجعه مشتری",
                    measurementId = null
                )
            )
            dao.insertOrderItems(
                listOf(
                    OrderItemEntity(orderId = o3Id, clothingType = "پیراهن", quantity = 2, unitPrice = 1400L, notes = "پیراهن جیب‌دار"),
                    OrderItemEntity(orderId = o3Id, clothingType = "پتلون", quantity = 2, unitPrice = 600L, notes = "پتلون کش‌دار")
                )
            )
            dao.insertPayment(
                PaymentEntity(
                    orderId = o3Id,
                    customerId = c3Id,
                    amount = 4000L,
                    paymentDateShamsi = today,
                    paymentMethod = "نقدی",
                    notes = "تسویه کامل نقدی"
                )
            )

            // Seed sample workshop expense
            dao.insertExpense(
                ExpenseEntity(
                    title = "خرید زیپ مخفی و دکمه‌های فلزی طرح کت",
                    amount = 1200L,
                    category = "ملحقات و دکمه",
                    expenseDateShamsi = today,
                    notes = "خرید از بازار پارچه‌فروشان کابل"
                )
            )
        }
    }
}
