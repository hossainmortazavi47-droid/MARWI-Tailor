package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

data class OrderWithCustomerInfo(
    val id: Long,
    val orderNumber: String,
    val customerId: Long,
    val orderType: String,
    val description: String,
    val registrationDateShamsi: String,
    val deliveryDateShamsi: String,
    val status: String,
    val totalAmount: Long,
    val advancePayment: Long,
    val remainingAmount: Long,
    val specialNotes: String,
    val measurementId: Long?,
    val createdAt: Long,
    val customerName: String,
    val customerPhone: String
)

@Dao
interface TailorDao {

    // --- CUSTOMERS ---
    @Query("SELECT * FROM customers ORDER BY createdAt DESC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id")
    fun getCustomerById(id: Long): Flow<CustomerEntity?>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerByIdDirect(id: Long): CustomerEntity?

    @Query("SELECT * FROM customers WHERE fullName LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchCustomers(query: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE phone = :phone LIMIT 1")
    suspend fun findCustomerByPhone(phone: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)

    // --- MEASUREMENTS ---
    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY updatedAt DESC")
    fun getMeasurementsForCustomer(customerId: Long): Flow<List<MeasurementEntity>>

    @Query("SELECT * FROM measurements WHERE id = :id")
    fun getMeasurementById(id: Long): Flow<MeasurementEntity?>

    @Query("SELECT * FROM measurements WHERE id = :id")
    suspend fun getMeasurementByIdDirect(id: Long): MeasurementEntity?

    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getLatestMeasurementForCustomer(customerId: Long): MeasurementEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: MeasurementEntity): Long

    @Update
    suspend fun updateMeasurement(measurement: MeasurementEntity)

    @Delete
    suspend fun deleteMeasurement(measurement: MeasurementEntity)

    // --- ORDERS ---
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("""
        SELECT orders.*, customers.fullName AS customerName, customers.phone AS customerPhone 
        FROM orders 
        INNER JOIN customers ON orders.customerId = customers.id 
        ORDER BY orders.createdAt DESC
    """)
    fun getAllOrdersWithCustomer(): Flow<List<OrderWithCustomerInfo>>

    @Query("""
        SELECT orders.*, customers.fullName AS customerName, customers.phone AS customerPhone 
        FROM orders 
        INNER JOIN customers ON orders.customerId = customers.id 
        WHERE orders.status = :status
        ORDER BY orders.createdAt DESC
    """)
    fun getOrdersWithCustomerByStatus(status: String): Flow<List<OrderWithCustomerInfo>>

    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getOrdersForCustomer(customerId: Long): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id")
    fun getOrderById(id: Long): Flow<OrderEntity?>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderByIdDirect(id: Long): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity): Long

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("UPDATE orders SET status = :status WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: Long, status: String)

    @Query("UPDATE orders SET remainingAmount = :newRemaining WHERE id = :orderId")
    suspend fun updateOrderRemaining(orderId: Long, newRemaining: Long)

    @Delete
    suspend fun deleteOrder(order: OrderEntity)

    // --- ORDER ITEMS ---
    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItems(orderId: Long): Flow<List<OrderItemEntity>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getOrderItemsDirect(orderId: Long): List<OrderItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItemEntity>)

    @Query("DELETE FROM order_items WHERE orderId = :orderId")
    suspend fun deleteOrderItemsByOrderId(orderId: Long)

    // --- PAYMENTS ---
    @Query("SELECT * FROM payments ORDER BY createdAt DESC")
    fun getAllPayments(): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE orderId = :orderId ORDER BY createdAt DESC")
    fun getPaymentsForOrder(orderId: Long): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getPaymentsForCustomer(customerId: Long): Flow<List<PaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Delete
    suspend fun deletePayment(payment: PaymentEntity)

    // --- EXPENSES ---
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    // --- SHOP SETTINGS ---
    @Query("SELECT * FROM shop_settings WHERE id = 1 LIMIT 1")
    fun getShopSettings(): Flow<ShopSettingsEntity?>

    @Query("SELECT * FROM shop_settings WHERE id = 1 LIMIT 1")
    suspend fun getShopSettingsDirect(): ShopSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: ShopSettingsEntity)

    // --- DASHBOARD AGGREGATES ---
    @Query("SELECT COUNT(*) FROM customers")
    fun getTotalCustomersCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM orders WHERE status = :status")
    fun getOrderCountByStatus(status: String): Flow<Int>

    @Query("SELECT SUM(remainingAmount) FROM orders WHERE status != 'CANCELLED' AND status != 'DELIVERED'")
    fun getTotalDebt(): Flow<Long?>

    @Query("SELECT SUM(amount) FROM payments WHERE paymentDateShamsi = :todayDate")
    fun getTodayIncome(todayDate: String): Flow<Long?>
}
