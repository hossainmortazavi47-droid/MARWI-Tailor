package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "measurements",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["customerId"])]
)
data class MeasurementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val title: String = "اندازه عمومی",
    val dateShamsi: String = "",
    // Jacket / Shirt measurements (پیراهن / کت)
    val shirtLength: String = "", // قد لباس
    val chest: String = "",       // دور سینه
    val waist: String = "",       // دور کمر
    val stomach: String = "",     // دور شکم
    val hips: String = "",        // دور باسن
    val shoulder: String = "",    // عرض شانه
    val sleeveLength: String = "",// طول آستین
    val armBicep: String = "",    // دور بازو
    val wrist: String = "",       // دور مچ
    val collar: String = "",      // دور گردن
    // Trousers measurements (پتلون / تنبان)
    val pantsLength: String = "", // قد پتلون
    val pantsWaist: String = "",  // دور کمر پتلون
    val thigh: String = "",       // دور ران
    val knee: String = "",        // دور زانو
    val pantsCuff: String = "",   // دمپای پتلون
    val crotch: String = "",      // فاق
    // Notes & custom specs
    val customNotes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
