package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object OrderStatus {
    const val PENDING = "PENDING"           // در انتظار دوخت
    const val IN_PROGRESS = "IN_PROGRESS"   // در حال دوخت
    const val READY = "READY"               // آماده تحویل
    const val DELIVERED = "DELIVERED"       // تحویل داده شد
    const val CANCELLED = "CANCELLED"       // لغو شده

    fun getPersianTitle(status: String): String = when (status) {
        PENDING -> "در انتظار دوخت"
        IN_PROGRESS -> "در حال دوخت"
        READY -> "آماده تحویل"
        DELIVERED -> "تحویل داده شد"
        CANCELLED -> "لغو شده"
        else -> status
    }
}

@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["customerId"]),
        Index(value = ["status"]),
        Index(value = ["deliveryDateShamsi"])
    ]
)
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderNumber: String,
    val customerId: Long,
    val orderType: String, // دریشی، پیراهن تنبان، واسکټ، پتلون، سایر
    val description: String = "",
    val registrationDateShamsi: String,
    val deliveryDateShamsi: String,
    val status: String = OrderStatus.PENDING,
    val totalAmount: Long,
    val advancePayment: Long,
    val remainingAmount: Long,
    val specialNotes: String = "",
    val measurementId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
