package com.example.data.repository

import com.example.data.local.CustomerEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.MeasurementEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.OrderWithCustomerInfo
import com.example.data.local.PaymentEntity
import com.example.data.local.ShopSettingsEntity
import com.example.data.local.TailorDao
import kotlinx.coroutines.flow.Flow
import kotlin.math.max

class TailorRepository(private val dao: TailorDao) {

    // --- Customers ---
    val allCustomers: Flow<List<CustomerEntity>> = dao.getAllCustomers()

    fun searchCustomers(query: String): Flow<List<CustomerEntity>> =
        if (query.isBlank()) dao.getAllCustomers() else dao.searchCustomers(query.trim())

    fun getCustomerById(id: Long): Flow<CustomerEntity?> = dao.getCustomerById(id)
    suspend fun getCustomerByIdDirect(id: Long): CustomerEntity? = dao.getCustomerByIdDirect(id)

    suspend fun findCustomerByPhone(phone: String): CustomerEntity? =
        dao.findCustomerByPhone(phone.trim())

    suspend fun saveCustomer(customer: CustomerEntity): Long =
        if (customer.id == 0L) dao.insertCustomer(customer) else {
            dao.updateCustomer(customer)
            customer.id
        }

    suspend fun deleteCustomer(customer: CustomerEntity) = dao.deleteCustomer(customer)

    // --- Measurements ---
    fun getMeasurementsForCustomer(customerId: Long): Flow<List<MeasurementEntity>> =
        dao.getMeasurementsForCustomer(customerId)

    fun getMeasurementById(id: Long): Flow<MeasurementEntity?> = dao.getMeasurementById(id)
    suspend fun getMeasurementByIdDirect(id: Long): MeasurementEntity? = dao.getMeasurementByIdDirect(id)

    suspend fun getLatestMeasurementForCustomer(customerId: Long): MeasurementEntity? =
        dao.getLatestMeasurementForCustomer(customerId)

    suspend fun saveMeasurement(measurement: MeasurementEntity): Long =
        if (measurement.id == 0L) dao.insertMeasurement(measurement) else {
            dao.updateMeasurement(measurement)
            measurement.id
        }

    suspend fun deleteMeasurement(measurement: MeasurementEntity) = dao.deleteMeasurement(measurement)

    // --- Orders ---
    val allOrdersWithCustomer: Flow<List<OrderWithCustomerInfo>> = dao.getAllOrdersWithCustomer()

    fun getOrdersWithCustomerByStatus(status: String): Flow<List<OrderWithCustomerInfo>> =
        if (status.isBlank() || status == "ALL") dao.getAllOrdersWithCustomer()
        else dao.getOrdersWithCustomerByStatus(status)

    fun getOrdersForCustomer(customerId: Long): Flow<List<OrderEntity>> = dao.getOrdersForCustomer(customerId)

    fun getOrderById(id: Long): Flow<OrderEntity?> = dao.getOrderById(id)
    suspend fun getOrderByIdDirect(id: Long): OrderEntity? = dao.getOrderByIdDirect(id)

    suspend fun createOrder(
        order: OrderEntity,
        items: List<OrderItemEntity>,
        initialPaymentAmount: Long,
        paymentMethod: String
    ): Long {
        val orderId = dao.insertOrder(order)
        if (items.isNotEmpty()) {
            val assignedItems = items.map { it.copy(orderId = orderId) }
            dao.insertOrderItems(assignedItems)
        }
        if (initialPaymentAmount > 0L) {
            dao.insertPayment(
                PaymentEntity(
                    orderId = orderId,
                    customerId = order.customerId,
                    amount = initialPaymentAmount,
                    paymentDateShamsi = order.registrationDateShamsi,
                    paymentMethod = paymentMethod,
                    notes = "پیش‌پرداخت اولیه ثبت سفارش ${order.orderNumber}"
                )
            )
        }
        return orderId
    }

    suspend fun updateOrder(order: OrderEntity, items: List<OrderItemEntity>? = null) {
        dao.updateOrder(order)
        if (items != null) {
            dao.deleteOrderItemsByOrderId(order.id)
            val assignedItems = items.map { it.copy(orderId = order.id) }
            dao.insertOrderItems(assignedItems)
        }
    }

    suspend fun updateOrderStatus(orderId: Long, status: String) =
        dao.updateOrderStatus(orderId, status)

    suspend fun deleteOrder(order: OrderEntity) = dao.deleteOrder(order)

    // --- Order Items ---
    fun getOrderItems(orderId: Long): Flow<List<OrderItemEntity>> = dao.getOrderItems(orderId)
    suspend fun getOrderItemsDirect(orderId: Long): List<OrderItemEntity> = dao.getOrderItemsDirect(orderId)

    // --- Payments ---
    val allPayments: Flow<List<PaymentEntity>> = dao.getAllPayments()

    fun getPaymentsForOrder(orderId: Long): Flow<List<PaymentEntity>> = dao.getPaymentsForOrder(orderId)
    fun getPaymentsForCustomer(customerId: Long): Flow<List<PaymentEntity>> = dao.getPaymentsForCustomer(customerId)

    suspend fun addPayment(
        orderId: Long,
        customerId: Long,
        amount: Long,
        paymentDateShamsi: String,
        paymentMethod: String,
        notes: String
    ): Long {
        val paymentId = dao.insertPayment(
            PaymentEntity(
                orderId = orderId,
                customerId = customerId,
                amount = amount,
                paymentDateShamsi = paymentDateShamsi,
                paymentMethod = paymentMethod,
                notes = notes
            )
        )
        // Automatically deduct from order remaining amount
        val order = dao.getOrderByIdDirect(orderId)
        if (order != null) {
            val newRemaining = max(0L, order.remainingAmount - amount)
            dao.updateOrderRemaining(orderId, newRemaining)
            // If completely paid and was pending/in_progress, keep track
            if (newRemaining == 0L && order.status == OrderStatus.READY) {
                // Keep ready
            }
        }
        return paymentId
    }

    suspend fun deletePayment(payment: PaymentEntity) {
        dao.deletePayment(payment)
        val order = dao.getOrderByIdDirect(payment.orderId)
        if (order != null) {
            dao.updateOrderRemaining(order.id, order.remainingAmount + payment.amount)
        }
    }

    // --- Expenses ---
    val allExpenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()

    suspend fun addExpense(expense: ExpenseEntity): Long = dao.insertExpense(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = dao.deleteExpense(expense)

    // --- Shop Settings ---
    val shopSettings: Flow<ShopSettingsEntity?> = dao.getShopSettings()
    suspend fun getShopSettingsDirect(): ShopSettingsEntity? = dao.getShopSettingsDirect()

    suspend fun saveShopSettings(settings: ShopSettingsEntity) =
        dao.insertOrUpdateSettings(settings)

    // --- Dashboard Aggregates ---
    val totalCustomersCount: Flow<Int> = dao.getTotalCustomersCount()
    fun getOrderCountByStatus(status: String): Flow<Int> = dao.getOrderCountByStatus(status)
    val totalDebt: Flow<Long?> = dao.getTotalDebt()
    fun getTodayIncome(todayDate: String): Flow<Long?> = dao.getTodayIncome(todayDate)
}
