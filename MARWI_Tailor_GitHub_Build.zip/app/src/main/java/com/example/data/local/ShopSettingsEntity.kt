package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shop_settings")
data class ShopSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val shopName: String = "خیاطی مردانه ماروی (MARWI Tailor Pro)",
    val tailorName: String = "استاد ماروی",
    val phone: String = "0799000000",
    val address: String = "کابل، چهارراهی انصاری، مارکت لوکس خیاطان",
    val currencyUnit: String = "افغانی",
    val receiptFooterNote: String = "با تشکر از اعتماد شما. پرو و تحویل فقط با ارائه این رسید امکان‌پذیر است.",
    val showCustomerPhoto: Boolean = true
)
