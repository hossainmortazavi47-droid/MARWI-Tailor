package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.TailorBottomNavBar
import com.example.ui.components.TailorNavigationRailBar
import com.example.ui.screens.customers.CustomerDetailScreen
import com.example.ui.screens.customers.CustomersScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.finance.FinanceScreen
import com.example.ui.screens.more.MoreScreen
import com.example.ui.screens.more.OverdueOrdersScreen
import com.example.ui.screens.more.ShopSettingsScreen
import com.example.ui.screens.orders.AddEditOrderScreen
import com.example.ui.screens.orders.OrderDetailScreen
import com.example.ui.screens.orders.OrdersScreen
import com.example.ui.theme.MarwiTailorTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            // Force RTL layout for complete Persian/Dari experience
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MarwiTailorTheme {
                    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

                    // Handle back presses inside the ViewModel stack
                    val isSubScreen = currentScreen !is ScreenDestination.Dashboard &&
                            currentScreen !is ScreenDestination.Customers &&
                            currentScreen !is ScreenDestination.Orders &&
                            currentScreen !is ScreenDestination.Finance &&
                            currentScreen !is ScreenDestination.More

                    BackHandler(enabled = true) {
                        if (!viewModel.navigateBack()) {
                            if (currentScreen != ScreenDestination.Dashboard) {
                                viewModel.navigateTo(ScreenDestination.Dashboard)
                            } else {
                                finish()
                            }
                        }
                    }

                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val isTablet = maxWidth >= 600.dp

                        if (isTablet) {
                            // Tablet Layout with Navigation Rail
                            Row(modifier = Modifier.fillMaxSize()) {
                                TailorNavigationRailBar(
                                    currentDestination = currentScreen,
                                    onTabSelected = { dest -> viewModel.navigateTo(dest) }
                                )

                                MainScreenContent(
                                    currentScreen = currentScreen,
                                    viewModel = viewModel,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        } else {
                            // Mobile Layout with Bottom Navigation Bar
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                bottomBar = {
                                    TailorBottomNavBar(
                                        currentDestination = currentScreen,
                                        onTabSelected = { dest -> viewModel.navigateTo(dest) }
                                    )
                                }
                            ) { innerPadding ->
                                MainScreenContent(
                                    currentScreen = currentScreen,
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MainScreenContent(
    currentScreen: ScreenDestination,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "ScreenTransition",
        modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
    ) { targetScreen ->
        when (targetScreen) {
            is ScreenDestination.Dashboard -> DashboardScreen(viewModel = viewModel)
            is ScreenDestination.Customers -> CustomersScreen(viewModel = viewModel)
            is ScreenDestination.CustomerDetail -> CustomerDetailScreen(
                customerId = targetScreen.customerId,
                viewModel = viewModel
            )
            is ScreenDestination.Orders -> OrdersScreen(viewModel = viewModel)
            is ScreenDestination.OrderDetail -> OrderDetailScreen(
                orderId = targetScreen.orderId,
                viewModel = viewModel
            )
            is ScreenDestination.AddEditOrder -> AddEditOrderScreen(
                preSelectedCustomerId = targetScreen.customerId,
                orderIdToEdit = targetScreen.orderId,
                viewModel = viewModel
            )
            is ScreenDestination.Finance -> FinanceScreen(viewModel = viewModel)
            is ScreenDestination.More -> MoreScreen(viewModel = viewModel)
            is ScreenDestination.OverdueOrders -> OverdueOrdersScreen(viewModel = viewModel)
            is ScreenDestination.ShopSettings -> ShopSettingsScreen(viewModel = viewModel)
        }
    }
}
