package com.example.utils

import java.util.Calendar
import java.util.Locale

data class PersianDate(
    val year: Int,
    val month: Int,
    val day: Int
) {
    fun format(): String = String.format(Locale.US, "%04d/%02d/%02d", year, month, day)

    fun toReadableString(): String {
        val monthNames = listOf(
            "حمل (فروردین)", "ثور (اردیبهشت)", "جوزا (خرداد)",
            "سرطان (تیر)", "اسد (مرداد)", "سنبله (شهریور)",
            "میزان (مهر)", "عقرب (آبان)", "قوس (آذر)",
            "جدی (دی)", "دلو (بهمن)", "حوت (اسفند)"
        )
        val mName = if (month in 1..12) monthNames[month - 1] else ""
        return "$day $mName $year"
    }
}

object PersianDateHelper {

    fun today(): PersianDate {
        val cal = Calendar.getInstance()
        return gregorianToPersian(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun todayFormatted(): String = today().format()

    fun todayReadableWithDayName(): String {
        val cal = Calendar.getInstance()
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val dayName = when (dayOfWeek) {
            Calendar.SATURDAY -> "شنبه"
            Calendar.SUNDAY -> "یکشنبه"
            Calendar.MONDAY -> "دوشنبه"
            Calendar.TUESDAY -> "سه‌شنبه"
            Calendar.WEDNESDAY -> "چهارشنبه"
            Calendar.THURSDAY -> "پنجشنبه"
            Calendar.FRIDAY -> "جمعه"
            else -> ""
        }
        val pDate = today()
        return "$dayName، ${pDate.toReadableString()}"
    }

    fun gregorianToPersian(gy: Int, gm: Int, gd: Int): PersianDate {
        val gDaysInMonth = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) (gy + 1) else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gDaysInMonth[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += ((days - 1) / 365)
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return PersianDate(jy, jm, jd)
    }

    fun parseDate(dateStr: String): PersianDate? {
        val parts = dateStr.trim().split("/", "-", ".")
        if (parts.size == 3) {
            val y = parts[0].toIntOrNull()
            val m = parts[1].toIntOrNull()
            val d = parts[2].toIntOrNull()
            if (y != null && m != null && d != null) {
                return PersianDate(y, m, d)
            }
        }
        return null
    }

    /**
     * Returns true if deliveryDate is today or past due and not finished
     */
    fun isOverdue(deliveryDateStr: String, todayStr: String = todayFormatted()): Boolean {
        return deliveryDateStr.trim().isNotEmpty() && deliveryDateStr.compareTo(todayStr) < 0
    }

    /**
     * Returns true if deliveryDate is today or within the next 3 days
     */
    fun isNearDelivery(deliveryDateStr: String, todayDate: PersianDate = today()): Boolean {
        val target = parseDate(deliveryDateStr) ?: return false
        val diffDays = daysDifference(todayDate, target)
        return diffDays in 0..3
    }

    /**
     * Approximate days difference between two Persian dates (positive if d2 > d1)
     */
    fun daysDifference(d1: PersianDate, d2: PersianDate): Int {
        val dayNum1 = d1.year * 365 + d1.month * 30 + d1.day
        val dayNum2 = d2.year * 365 + d2.month * 30 + d2.day
        return dayNum2 - dayNum1
    }

    fun addDaysToToday(days: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, days)
        val p = gregorianToPersian(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        return p.format()
    }
}
