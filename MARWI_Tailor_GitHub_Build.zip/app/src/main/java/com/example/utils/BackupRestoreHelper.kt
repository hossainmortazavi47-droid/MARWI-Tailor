package com.example.utils

import com.example.data.local.CustomerEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.MeasurementEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.ShopSettingsEntity
import com.example.data.repository.TailorRepository
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

data class BackupData(
    val customers: List<CustomerEntity>,
    val measurements: List<MeasurementEntity>,
    val orders: List<OrderEntity>,
    val orderItems: List<OrderItemEntity>,
    val payments: List<PaymentEntity>,
    val expenses: List<ExpenseEntity>,
    val settings: ShopSettingsEntity?
)

object BackupRestoreHelper {

    suspend fun createBackupJson(repository: TailorRepository): String {
        val customers = repository.allCustomers.first()
        val orders = repository.allOrdersWithCustomer.first()
        val payments = repository.allPayments.first()
        val expenses = repository.allExpenses.first()
        val settings = repository.getShopSettingsDirect()

        val root = JSONObject()
        root.put("version", 1)
        root.put("backupDate", PersianDateHelper.todayFormatted())
        root.put("timestamp", System.currentTimeMillis())

        // Customers
        val customersArray = JSONArray()
        for (c in customers) {
            val cObj = JSONObject().apply {
                put("id", c.id)
                put("fullName", c.fullName)
                put("phone", c.phone)
                put("address", c.address)
                put("notes", c.notes)
                put("createdAt", c.createdAt)
            }
            customersArray.put(cObj)
        }
        root.put("customers", customersArray)

        // Orders
        val ordersArray = JSONArray()
        val allOrderItems = mutableListOf<OrderItemEntity>()
        for (o in orders) {
            val oObj = JSONObject().apply {
                put("id", o.id)
                put("orderNumber", o.orderNumber)
                put("customerId", o.customerId)
                put("orderType", o.orderType)
                put("description", o.description)
                put("registrationDateShamsi", o.registrationDateShamsi)
                put("deliveryDateShamsi", o.deliveryDateShamsi)
                put("status", o.status)
                put("totalAmount", o.totalAmount)
                put("advancePayment", o.advancePayment)
                put("remainingAmount", o.remainingAmount)
                put("specialNotes", o.specialNotes)
                put("createdAt", o.createdAt)
            }
            ordersArray.put(oObj)

            val items = repository.getOrderItemsDirect(o.id)
            allOrderItems.addAll(items)
        }
        root.put("orders", ordersArray)

        // Order Items
        val itemsArray = JSONArray()
        for (item in allOrderItems) {
            val itemObj = JSONObject().apply {
                put("id", item.id)
                put("orderId", item.orderId)
                put("clothingType", item.clothingType)
                put("quantity", item.quantity)
                put("unitPrice", item.unitPrice)
                put("notes", item.notes)
            }
            itemsArray.put(itemObj)
        }
        root.put("orderItems", itemsArray)

        // Payments
        val paymentsArray = JSONArray()
        for (p in payments) {
            val pObj = JSONObject().apply {
                put("id", p.id)
                put("orderId", p.orderId)
                put("customerId", p.customerId)
                put("amount", p.amount)
                put("paymentDateShamsi", p.paymentDateShamsi)
                put("paymentMethod", p.paymentMethod)
                put("notes", p.notes)
                put("createdAt", p.createdAt)
            }
            paymentsArray.put(pObj)
        }
        root.put("payments", paymentsArray)

        // Expenses
        val expensesArray = JSONArray()
        for (e in expenses) {
            val eObj = JSONObject().apply {
                put("id", e.id)
                put("title", e.title)
                put("amount", e.amount)
                put("category", e.category)
                put("expenseDateShamsi", e.expenseDateShamsi)
                put("notes", e.notes)
                put("createdAt", e.createdAt)
            }
            expensesArray.put(eObj)
        }
        root.put("expenses", expensesArray)

        // Settings
        if (settings != null) {
            val sObj = JSONObject().apply {
                put("shopName", settings.shopName)
                put("tailorName", settings.tailorName)
                put("phone", settings.phone)
                put("address", settings.address)
                put("currencyUnit", settings.currencyUnit)
                put("receiptFooterNote", settings.receiptFooterNote)
            }
            root.put("settings", sObj)
        }

        return root.toString(2)
    }

    suspend fun restoreFromJson(jsonStr: String, repository: TailorRepository): Result<String> {
        return try {
            val root = JSONObject(jsonStr)

            // Settings restore
            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                repository.saveShopSettings(
                    ShopSettingsEntity(
                        id = 1,
                        shopName = sObj.optString("shopName", "MARWI Tailor Pro"),
                        tailorName = sObj.optString("tailorName", "استاد خیاط"),
                        phone = sObj.optString("phone", ""),
                        address = sObj.optString("address", ""),
                        currencyUnit = sObj.optString("currencyUnit", "افغانی"),
                        receiptFooterNote = sObj.optString("receiptFooterNote", "")
                    )
                )
            }

            var restoredCustomers = 0
            if (root.has("customers")) {
                val arr = root.getJSONArray("customers")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val phone = obj.optString("phone", "")
                    val existing = repository.findCustomerByPhone(phone)
                    if (existing == null) {
                        repository.saveCustomer(
                            CustomerEntity(
                                fullName = obj.optString("fullName", ""),
                                phone = phone,
                                address = obj.optString("address", ""),
                                notes = obj.optString("notes", ""),
                                createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                            )
                        )
                        restoredCustomers++
                    }
                }
            }

            Result.success("بازیابی با موفقیت انجام شد ($restoredCustomers مشتری افزوده شد)")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
