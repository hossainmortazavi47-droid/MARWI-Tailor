package com.example.utils

import android.content.Context
import android.content.Intent
import com.example.data.local.CustomerEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.ShopSettingsEntity

object InvoiceGenerator {

    fun generateTextInvoice(
        settings: ShopSettingsEntity,
        customer: CustomerEntity,
        order: OrderEntity,
        items: List<OrderItemEntity>
    ): String {
        val currency = settings.currencyUnit
        val divider = "════════════════════════════════════"
        val line = "────────────────────────────────────"

        val sb = StringBuilder()
        sb.appendLine("✦ ${settings.shopName} ✦")
        sb.appendLine("مدیریت: ${settings.tailorName}")
        sb.appendLine("شماره تماس: ${settings.phone}")
        if (settings.address.isNotBlank()) {
            sb.appendLine("نشانی: ${settings.address}")
        }
        sb.appendLine(divider)
        sb.appendLine("قبض سفارش خیاطی: ${order.orderNumber}")
        sb.appendLine("تاریخ ثبت: ${order.registrationDateShamsi}")
        sb.appendLine("موعد تحویل: ${order.deliveryDateShamsi}")
        sb.appendLine("وضعیت: ${OrderStatus.getPersianTitle(order.status)}")
        sb.appendLine(divider)
        sb.appendLine("مشخصات محترم مشتری:")
        sb.appendLine("نام: ${customer.fullName}")
        sb.appendLine("شماره تماس: ${customer.phone}")
        sb.appendLine(divider)
        sb.appendLine("اقلام و مدل لباس:")
        sb.appendLine("نوع کلی: ${order.orderType}")
        if (order.description.isNotBlank()) {
            sb.appendLine("توضیحات پارچه/مدل: ${order.description}")
        }
        if (items.isNotEmpty()) {
            sb.appendLine(line)
            items.forEachIndexed { index, item ->
                val itemPriceStr = if (item.unitPrice > 0) " (${CurrencyFormatter.format(item.unitPrice, currency)})" else ""
                val notesStr = if (item.notes.isNotBlank()) " - ${item.notes}" else ""
                sb.appendLine("${index + 1}. ${item.clothingType} × ${item.quantity}$itemPriceStr$notesStr")
            }
        }
        sb.appendLine(divider)
        sb.appendLine("مبلغ کل سفارش: ${CurrencyFormatter.format(order.totalAmount, currency)}")
        sb.appendLine("پیش‌پرداخت دریافتی: ${CurrencyFormatter.format(order.advancePayment, currency)}")
        sb.appendLine("باقیمانده حساب (بدهی): ${CurrencyFormatter.format(order.remainingAmount, currency)}")
        sb.appendLine(divider)
        if (order.specialNotes.isNotBlank()) {
            sb.appendLine("یادداشت اختصاصی: ${order.specialNotes}")
            sb.appendLine(line)
        }
        sb.appendLine(settings.receiptFooterNote)
        sb.appendLine("« MARWI Tailor Pro - سیستم مدیریت خیاطی »")

        return sb.toString()
    }

    fun shareInvoice(context: Context, invoiceText: String, orderNumber: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "قبض سفارش $orderNumber")
            putExtra(Intent.EXTRA_TEXT, invoiceText)
        }
        context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری قبض خیاطی"))
    }
}
