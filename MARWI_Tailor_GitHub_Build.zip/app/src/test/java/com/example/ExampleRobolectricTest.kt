package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CustomerEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.ShopSettingsEntity
import com.example.utils.CurrencyFormatter
import com.example.utils.InvoiceGenerator
import com.example.utils.PersianDateHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MARWI Tailor Pro", appName)
    }

    @Test
    fun `test PersianDateHelper conversions and formatting`() {
        // Test Gregorian to Jalali conversion: 2026-10-29 is 1405/08/07 or 1405/08/08
        val pDate = PersianDateHelper.gregorianToPersian(2026, 10, 29)
        assertEquals(1405, pDate.year)
        assertEquals(8, pDate.month)
        assertTrue(pDate.day in 7..8)

        val formatted = pDate.format()
        assertTrue(formatted.startsWith("1405/08/"))
    }

    @Test
    fun `test CurrencyFormatter formatting`() {
        val formatted = CurrencyFormatter.format(1500000L, "افغانی")
        assertEquals("1,500,000 افغانی", formatted)
    }

    @Test
    fun `test InvoiceGenerator outputs receipt text`() {
        val settings = ShopSettingsEntity(shopName = "MARWI Tailor Pro", currencyUnit = "افغانی")
        val customer = CustomerEntity(id = 1, fullName = "احمد شریفی", phone = "0799112233")
        val order = OrderEntity(
            orderNumber = "ORD-101",
            customerId = 1,
            orderType = "دریشی",
            registrationDateShamsi = "1405/08/01",
            deliveryDateShamsi = "1405/08/10",
            status = OrderStatus.PENDING,
            totalAmount = 8000L,
            advancePayment = 3000L,
            remainingAmount = 5000L
        )
        val items = listOf(
            OrderItemEntity(orderId = 1, clothingType = "کت و شلوار", quantity = 1, unitPrice = 8000L)
        )

        val invoice = InvoiceGenerator.generateTextInvoice(settings, customer, order, items)
        assertTrue(invoice.contains("MARWI Tailor Pro"))
        assertTrue(invoice.contains("احمد شریفی"))
        assertTrue(invoice.contains("8,000 افغانی"))
        assertTrue(invoice.contains("5,000 افغانی"))
    }
}
